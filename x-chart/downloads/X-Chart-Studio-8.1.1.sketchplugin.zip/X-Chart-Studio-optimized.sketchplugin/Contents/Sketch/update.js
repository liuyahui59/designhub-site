var globalThis = this;
var global = this;
function __skpm_run (key, context) {
  globalThis.context = context;
  try {

var exports;
/******/ (() => { // webpackBootstrap
/******/ 	var __webpack_modules__ = ({

/***/ "./node_modules/@skpm/promise/index.js"
/*!*********************************************!*\
  !*** ./node_modules/@skpm/promise/index.js ***!
  \*********************************************/
(module) {

/* from https://github.com/taylorhakes/promise-polyfill */

function promiseFinally(callback) {
  var constructor = this.constructor;
  return this.then(
    function(value) {
      return constructor.resolve(callback()).then(function() {
        return value;
      });
    },
    function(reason) {
      return constructor.resolve(callback()).then(function() {
        return constructor.reject(reason);
      });
    }
  );
}

function noop() {}

/**
 * @constructor
 * @param {Function} fn
 */
function Promise(fn) {
  if (!(this instanceof Promise))
    throw new TypeError("Promises must be constructed via new");
  if (typeof fn !== "function") throw new TypeError("not a function");
  /** @type {!number} */
  this._state = 0;
  /** @type {!boolean} */
  this._handled = false;
  /** @type {Promise|undefined} */
  this._value = undefined;
  /** @type {!Array<!Function>} */
  this._deferreds = [];

  doResolve(fn, this);
}

function handle(self, deferred) {
  while (self._state === 3) {
    self = self._value;
  }
  if (self._state === 0) {
    self._deferreds.push(deferred);
    return;
  }
  self._handled = true;
  Promise._immediateFn(function() {
    var cb = self._state === 1 ? deferred.onFulfilled : deferred.onRejected;
    if (cb === null) {
      (self._state === 1 ? resolve : reject)(deferred.promise, self._value);
      return;
    }
    var ret;
    try {
      ret = cb(self._value);
    } catch (e) {
      reject(deferred.promise, e);
      return;
    }
    resolve(deferred.promise, ret);
  });
}

function resolve(self, newValue) {
  try {
    // Promise Resolution Procedure: https://github.com/promises-aplus/promises-spec#the-promise-resolution-procedure
    if (newValue === self)
      throw new TypeError("A promise cannot be resolved with itself.");
    if (
      newValue &&
      (typeof newValue === "object" || typeof newValue === "function")
    ) {
      var then = newValue.then;
      if (newValue instanceof Promise) {
        self._state = 3;
        self._value = newValue;
        finale(self);
        return;
      } else if (typeof then === "function") {
        doResolve(then.bind(newValue), self);
        return;
      }
    }
    self._state = 1;
    self._value = newValue;
    finale(self);
  } catch (e) {
    reject(self, e);
  }
}

function reject(self, newValue) {
  self._state = 2;
  self._value = newValue;
  finale(self);
}

function finale(self) {
  if (self._state === 2 && self._deferreds.length === 0) {
    Promise._immediateFn(function() {
      if (!self._handled) {
        Promise._unhandledRejectionFn(self._value, self);
      }
    });
  }

  for (var i = 0, len = self._deferreds.length; i < len; i++) {
    handle(self, self._deferreds[i]);
  }
  self._deferreds = null;
}

/**
 * @constructor
 */
function Handler(onFulfilled, onRejected, promise) {
  this.onFulfilled = typeof onFulfilled === "function" ? onFulfilled : null;
  this.onRejected = typeof onRejected === "function" ? onRejected : null;
  this.promise = promise;
}

/**
 * Take a potentially misbehaving resolver function and make sure
 * onFulfilled and onRejected are only called once.
 *
 * Makes no guarantees about asynchrony.
 */
function doResolve(fn, self) {
  var done = false;
  try {
    fn(
      function(value) {
        if (done) {
          Promise._multipleResolvesFn("resolve", self, value);
          return;
        }
        done = true;
        resolve(self, value);
      },
      function(reason) {
        if (done) {
          Promise._multipleResolvesFn("reject", self, reason);
          return;
        }
        done = true;
        reject(self, reason);
      }
    );
  } catch (ex) {
    if (done) {
      Promise._multipleResolvesFn("reject", self, ex);
      return;
    }
    done = true;
    reject(self, ex);
  }
}

Promise.prototype["catch"] = function(onRejected) {
  return this.then(null, onRejected);
};

Promise.prototype.then = function(onFulfilled, onRejected) {
  // @ts-ignore
  var prom = new this.constructor(noop);

  handle(this, new Handler(onFulfilled, onRejected, prom));
  return prom;
};

Promise.prototype["finally"] = promiseFinally;

Promise.all = function(arr) {
  return new Promise(function(resolve, reject) {
    if (!Array.isArray(arr)) {
      return reject(new TypeError("Promise.all accepts an array"));
    }

    var args = Array.prototype.slice.call(arr);
    if (args.length === 0) return resolve([]);
    var remaining = args.length;

    function res(i, val) {
      try {
        if (val && (typeof val === "object" || typeof val === "function")) {
          var then = val.then;
          if (typeof then === "function") {
            then.call(
              val,
              function(val) {
                res(i, val);
              },
              reject
            );
            return;
          }
        }
        args[i] = val;
        if (--remaining === 0) {
          resolve(args);
        }
      } catch (ex) {
        reject(ex);
      }
    }

    for (var i = 0; i < args.length; i++) {
      res(i, args[i]);
    }
  });
};

Promise.resolve = function(value) {
  if (value && typeof value === "object" && value.constructor === Promise) {
    return value;
  }

  return new Promise(function(resolve) {
    resolve(value);
  });
};

Promise.reject = function(value) {
  return new Promise(function(resolve, reject) {
    reject(value);
  });
};

Promise.race = function(arr) {
  return new Promise(function(resolve, reject) {
    if (!Array.isArray(arr)) {
      return reject(new TypeError("Promise.race accepts an array"));
    }

    for (var i = 0, len = arr.length; i < len; i++) {
      Promise.resolve(arr[i]).then(resolve, reject);
    }
  });
};

// Use polyfill for setImmediate for performance gains
Promise._immediateFn = setImmediate;

Promise._unhandledRejectionFn = function _unhandledRejectionFn(err, promise) {
  if (
    typeof process !== "undefined" &&
    process.listenerCount &&
    (process.listenerCount("unhandledRejection") ||
      process.listenerCount("uncaughtException"))
  ) {
    process.emit("unhandledRejection", err, promise);
    process.emit("uncaughtException", err, "unhandledRejection");
  } else if (typeof console !== "undefined" && console) {
    console.warn("Possible Unhandled Promise Rejection:", err);
  }
};

Promise._multipleResolvesFn = function _multipleResolvesFn(
  type,
  promise,
  value
) {
  if (typeof process !== "undefined" && process.emit) {
    process.emit("multipleResolves", type, promise, value);
  }
};

module.exports = Promise;


/***/ },

/***/ "./src/common.js"
/*!***********************!*\
  !*** ./src/common.js ***!
  \***********************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   chartUpdatable: () => (/* binding */ chartUpdatable),
/* harmony export */   checkSubscribtion: () => (/* binding */ checkSubscribtion),
/* harmony export */   collectStats: () => (/* binding */ collectStats),
/* harmony export */   colorIndex: () => (/* binding */ colorIndex),
/* harmony export */   convertToTemplate: () => (/* binding */ convertToTemplate),
/* harmony export */   createAreaChart: () => (/* binding */ createAreaChart),
/* harmony export */   createAxes: () => (/* binding */ createAxes),
/* harmony export */   createCandlestickChart: () => (/* binding */ createCandlestickChart),
/* harmony export */   createChart: () => (/* binding */ createChart),
/* harmony export */   createDonutChart: () => (/* binding */ createDonutChart),
/* harmony export */   createDots: () => (/* binding */ createDots),
/* harmony export */   createGroupBarChart: () => (/* binding */ createGroupBarChart),
/* harmony export */   createGroupHorizontalBarChart: () => (/* binding */ createGroupHorizontalBarChart),
/* harmony export */   createHorizontalBarChart: () => (/* binding */ createHorizontalBarChart),
/* harmony export */   createLineChart: () => (/* binding */ createLineChart),
/* harmony export */   createOval: () => (/* binding */ createOval),
/* harmony export */   createPieChart: () => (/* binding */ createPieChart),
/* harmony export */   createProgressChart: () => (/* binding */ createProgressChart),
/* harmony export */   createRandomData: () => (/* binding */ createRandomData),
/* harmony export */   createScatterPlot: () => (/* binding */ createScatterPlot),
/* harmony export */   createSparkline: () => (/* binding */ createSparkline),
/* harmony export */   createStackedAreaChart: () => (/* binding */ createStackedAreaChart),
/* harmony export */   createVerticalBarChart: () => (/* binding */ createVerticalBarChart),
/* harmony export */   curveToPoint: () => (/* binding */ curveToPoint),
/* harmony export */   defaultConf: () => (/* binding */ defaultConf),
/* harmony export */   getCanvas: () => (/* binding */ getCanvas),
/* harmony export */   lineToPoint: () => (/* binding */ lineToPoint),
/* harmony export */   migrateCandleColors: () => (/* binding */ migrateCandleColors),
/* harmony export */   moveToPoint: () => (/* binding */ moveToPoint),
/* harmony export */   path: () => (/* binding */ path),
/* harmony export */   polarToCartesian: () => (/* binding */ polarToCartesian),
/* harmony export */   processData: () => (/* binding */ processData),
/* harmony export */   processJSON: () => (/* binding */ processJSON),
/* harmony export */   xAxisDistrGrid: () => (/* binding */ xAxisDistrGrid),
/* harmony export */   xAxisDistrLabels: () => (/* binding */ xAxisDistrLabels),
/* harmony export */   xAxisGrid: () => (/* binding */ xAxisGrid),
/* harmony export */   xAxisLabels: () => (/* binding */ xAxisLabels),
/* harmony export */   yAxisGrid: () => (/* binding */ yAxisGrid),
/* harmony export */   yAxisLabels: () => (/* binding */ yAxisLabels)
/* harmony export */ });
/* harmony import */ var _babel_runtime_helpers_typeof__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/typeof */ "./node_modules/@babel/runtime/helpers/esm/typeof.js");
/* harmony import */ var _babel_runtime_helpers_toConsumableArray__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime/helpers/toConsumableArray */ "./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js");
/* harmony import */ var _nicenum__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./nicenum */ "./src/nicenum.js");




// return the status of subscription
// 本改造版为全功能免费版（仅个人自用），已移除付费校验
function checkSubscribtion(email) {
  var Settings = __webpack_require__(/*! sketch/settings */ "sketch/settings");
  Settings.setGlobalSettingForKey('user_status', true);
}

// collect stats（已移除：不再向第三方上报任何数据）
function collectStats(userId, email, appVersion, option, meta) {
  return;
}

// Generated default configuration from Resources/xchart-default-template.js.
// Keep this bundle copy in sync through the build step; migrations remain below.
function defaultConf() {
  var Settings = __webpack_require__(/*! sketch/settings */ "sketch/settings");
  var template = [{
    "name": "Default template",
    "id": 0,
    "templateVersion": 3,
    "colors": {
      "common": ["#0a84ff", "#30b0c7", "#ff9f0a", "#ff375f", "#5e5ce6", "#34c759"],
      "progressChart": ["#0a84ff"],
      "sparkline": ["#0a84ff"],
      "scatterPlot": ["#0a84ff", "#30b0c7", "#ff9f0a", "#ff375f", "#5e5ce6", "#34c759"],
      "candlestickChart": ["#da1e28", "#198038"]
    },
    "grid": {
      "type": 1,
      "lineWidth": 1,
      "color": "#e0e0e0",
      "yAxisSegments": 0
    },
    "labels": {
      "type": 1,
      "fontName": "IBM Plex Sans",
      "fontSize": 12,
      "color": "#525252",
      "yAxisPosition": "left",
      "xAxisPosition": "bottom",
      "xAxis": {
        "line": true,
        "ticks": true,
        "fontSize": 12,
        "color": "#525252"
      },
      "yAxis": {
        "line": true,
        "ticks": true,
        "fontSize": 12,
        "color": "#525252"
      }
    },
    "beginAtZero": 0,
    "lineType": 0,
    "sorting": 0,
    "typeOfCircle": 0,
    "segmentGap": 0,
    "interaction": {
      "showValueTooltip": true
    },
    "lineChart": {
      "lineWidth": 1.5,
      "dotType": 1,
      "dotDiameter": 5
    },
    "areaChart": {
      "lineWidth": 2,
      "opacity": 0.22,
      "type": "normal",
      "fillStyle": "gradient-line"
    },
    "verticalBarChart": {
      "margin": 0.24,
      "stackGap": 1,
      "roundTop": 0,
      "useOneColor": false
    },
    "percentStackedVerticalBarChart": {
      "margin": 0.24,
      "stackGap": 1,
      "roundTop": 0
    },
    "horizontalBarChart": {
      "margin": 0.24,
      "stackGap": 1,
      "roundTop": 0,
      "useOneColor": false
    },
    "percentStackedHorizontalBarChart": {
      "margin": 0.24,
      "stackGap": 1,
      "roundTop": 0
    },
    "groupedBarChart": {
      "margin": 0.2,
      "innerGap": 0.12,
      "roundTop": 0
    },
    "groupedHorizontalBarChart": {
      "margin": 0.2,
      "innerGap": 0.12,
      "roundTop": 0
    },
    "donutChart": {
      "thicknessOfDonut": 28
    },
    "progressChart": {
      "backgroundColor": "#e0e0e0",
      "thicknessOfProgress": 12,
      "endOfLine": 1
    },
    "sparkline": {
      "lineWidth": 1.5,
      "dotDiameter": 4
    },
    "scatterPlot": {
      "dotDiameter": 7
    },
    "candlestickChart": {
      "margin": 0.2,
      "unfilledNegativeBoxes": false
    }
  }];
  Settings.setGlobalSettingForKey('xchart.templates', JSON.stringify(template));
}

// Migrate built-in defaults and the legacy candlestick color order.
// User-created templates keep their settings.
function migrateCandleColors() {
  var Settings = __webpack_require__(/*! sketch/settings */ "sketch/settings");
  var raw = Settings.globalSettingForKey('xchart.templates');
  if (raw == undefined || raw == null) return;
  try {
    var templates = JSON.parse(raw);
    if (!Array.isArray(templates)) return;
    var changed = false;
    var previousDefaultPalette = ['#0f62fe', '#24a148', '#ff832b', '#da1e28', '#8a3ffc', '#007d79'];
    var defaultPalette = ['#0a84ff', '#30b0c7', '#ff9f0a', '#ff375f', '#5e5ce6', '#34c759'];
    templates.forEach(function (t) {
      var c = t.colors && t.colors.candlestickChart;
      var common = t.colors && t.colors.common;
      if (Number(t.id) === 0 && t.colors && (!Array.isArray(t.colors.scatterPlot) || t.colors.scatterPlot.length < defaultPalette.length)) {
        t.colors.scatterPlot = defaultPalette.slice();
        changed = true;
      }
      if (Number(t.id) === 0 && Array.isArray(common) && common.length === previousDefaultPalette.length && common.every(function (color, index) {
        return String(color).toLowerCase() === previousDefaultPalette[index];
      })) {
        t.colors.common = defaultPalette.slice();
        if (Array.isArray(t.colors.progressChart) && String(t.colors.progressChart[0]).toLowerCase() === '#0f62fe') t.colors.progressChart = ['#0a84ff'];
        if (Array.isArray(t.colors.sparkline) && String(t.colors.sparkline[0]).toLowerCase() === '#0f62fe') t.colors.sparkline = ['#0a84ff'];
        if (Array.isArray(t.colors.scatterPlot) && String(t.colors.scatterPlot[0]).toLowerCase() === '#0f62fe') t.colors.scatterPlot = defaultPalette.slice();
        changed = true;
      }
      if (Array.isArray(c) && c.length === 2 && c[0] === '#198038' && c[1] === '#da1e28') {
        t.colors.candlestickChart = ['#da1e28', '#198038'];
        changed = true;
      }
      // Upgrade the persisted built-in template as a whole. User-created templates
      // keep their settings; only template id 0 and legacy/default-shaped values change.
      if (Number(t.id) === 0 && t.colors && Array.isArray(t.colors.common)) {
        var looksLegacy = Number(t.templateVersion || 0) < 2 || t.colors.common.some(function (color) { return ['#6929c4', '#1192e8', '#005d5d'].indexOf(String(color).toLowerCase()) >= 0; }) ||
          (t.lineChart && Number(t.lineChart.lineWidth) === 2) || (t.areaChart && (t.areaChart.fillStyle === 'solid' || Number(t.areaChart.opacity) >= 0.4)) ||
          (t.verticalBarChart && Number(t.verticalBarChart.margin) === 0.4) || (t.labels && t.labels.color === '#6f6f6f');
        if (looksLegacy) {
          t.colors.common = defaultPalette.slice();
          t.colors.progressChart = ['#0a84ff']; t.colors.sparkline = ['#0a84ff']; t.colors.scatterPlot = defaultPalette.slice(); t.colors.candlestickChart = ['#da1e28', '#198038'];
          t.grid = { type: 1, lineWidth: 1, color: '#e0e0e0', yAxisSegments: 0 };
          t.labels = { type: 1, fontName: 'IBM Plex Sans', fontSize: 12, color: '#525252', yAxisPosition: 'left', xAxisPosition: 'bottom', xAxis: { line: true, ticks: true, fontSize: 12, color: '#525252' }, yAxis: { line: true, ticks: true, fontSize: 12, color: '#525252' } };
          t.lineChart = { lineWidth: 1.5, dotType: 1, dotDiameter: 5 };
          t.areaChart = { lineWidth: 2, opacity: 0.22, fillStyle: 'gradient-line' };
          t.verticalBarChart = { margin: 0.24, stackGap: 1, roundTop: 0, useOneColor: false };
          t.horizontalBarChart = { margin: 0.24, stackGap: 1, roundTop: 0, useOneColor: false };
          t.percentStackedVerticalBarChart = { margin: 0.24, stackGap: 1, roundTop: 0 }; t.percentStackedHorizontalBarChart = { margin: 0.24, stackGap: 1, roundTop: 0 };
          t.groupedBarChart = { margin: 0.2, innerGap: 0.12, roundTop: 0 }; t.groupedHorizontalBarChart = { margin: 0.2, innerGap: 0.12, roundTop: 0 };
          t.combo = { axisAssignment: 'auto', margin: 0.24, innerGap: 0.12, roundTop: 0 };
          t.donutChart = { thicknessOfDonut: 28 }; t.progressChart = { backgroundColor: '#e0e0e0', thicknessOfProgress: 12, endOfLine: 1 }; t.sparkline = { lineWidth: 1.5, dotDiameter: 4 }; t.scatterPlot = { dotDiameter: 7 }; t.candlestickChart = { margin: 0.2, unfilledNegativeBoxes: false };
          t.templateVersion = 3; changed = true;
        }
        if (Number(t.templateVersion || 0) < 3) {
          ['verticalBarChart', 'horizontalBarChart', 'percentStackedVerticalBarChart', 'percentStackedHorizontalBarChart', 'groupedBarChart', 'groupedHorizontalBarChart', 'combo'].forEach(function (key) {
            if (t[key] && Number(t[key].roundTop) === 4) t[key].roundTop = 0;
          });
          t.templateVersion = 3;
          changed = true;
        }
      }
    });
    if (changed) Settings.setGlobalSettingForKey('xchart.templates', JSON.stringify(templates));
  } catch (e) {}
}
function convertToTemplate() {
  var Settings = __webpack_require__(/*! sketch/settings */ "sketch/settings");
  var oldConf = JSON.parse(Settings.globalSettingForKey('conf'));
  var template = [{
    "name": "Default template",
    "id": 0,
    "colors": {
      "common": oldConf.lineChart.colors,
      "progressChart": oldConf.progressChart.colors,
      "sparkline": oldConf.sparkline.colors,
      "scatterPlot": oldConf.scatterPlot.colors,
      "candlestickChart": oldConf.candlestickChart.colors
    },
    "grid": {
      "type": Number(oldConf.lineChart.grid),
      "lineWidth": 1,
      "color": "#e0e0e0",
      "yAxisSegments": 0
    },
    "labels": {
      "type": Number(oldConf.lineChart.labels),
      "fontName": "IBM Plex Sans",
      "fontSize": 10,
      "color": "#6f6f6f",
      "yAxisPosition": "left",
      "xAxisPosition": "bottom",
      "xAxis": {
        "line": true,
        "ticks": true,
        "fontSize": 10,
        "color": "#6f6f6f"
      },
      "yAxis": {
        "line": true,
        "ticks": true,
        "fontSize": 10,
        "color": "#6f6f6f"
      }
    },
    "beginAtZero": 0,
    "lineType": Number(oldConf.lineChart.typeOfLine),
    "sorting": Number(oldConf.pieChart.sort),
    "typeOfCircle": Number(oldConf.pieChart.type),
    "lineChart": {
      "lineWidth": Number(oldConf.lineChart.thickness),
      "dotType": Number(oldConf.lineChart.dots),
      "dotDiameter": Number(oldConf.lineChart.diameter)
    },
    "areaChart": {
      "lineWidth": 0,
      "opacity": 0.4,
      "type": "normal",
      "fillStyle": "solid"
    },
    "verticalBarChart": {
      "margin": Number(oldConf.verticalBarChart.barWidth),
      "roundTop": 0,
      "useOneColor": true
    },
    "horizontalBarChart": {
      "margin": Number(oldConf.horizontalBarChart.barWidth),
      "roundTop": 0,
      "useOneColor": true
    },
    "groupedBarChart": {
      "margin": 0.4,
      "roundTop": 0
    },
    "groupedHorizontalBarChart": {
      "margin": 0.4,
      "roundTop": 0
    },
    "donutChart": {
      "thicknessOfDonut": Number(oldConf.donutChart.thickness)
    },
    "progressChart": {
      "backgroundColor": "#e0e0e0",
      "thicknessOfProgress": Number(oldConf.progressChart.thickness),
      "endOfLine": Number(oldConf.progressChart.end)
    },
    "sparkline": {
      "lineWidth": Number(oldConf.sparkline.thickness),
      "dotDiameter": Number(oldConf.sparkline.diameter)
    },
    "scatterPlot": {
      "dotDiameter": Number(oldConf.scatterPlot.diameter)
    },
    "candlestickChart": {
      "margin": Number(oldConf.candlestickChart.margin),
      "unfilledNegativeBoxes": false
    }
  }];
  Settings.setGlobalSettingForKey('xchart.templates', JSON.stringify(template));
}

// function that returns all parameters of canvases
function getCanvas(context) {
  var sketch = __webpack_require__(/*! sketch */ "sketch"),
    UI = __webpack_require__(/*! sketch/ui */ "sketch/ui"),
    Settings = __webpack_require__(/*! sketch/settings */ "sketch/settings"),
    doc = sketch.getSelectedDocument();
  var selection = doc.selectedLayers,
    canvasArr = new Array(),
    error = false,
    canvas;
  function isNumeric(n) {
    return !isNaN(parseFloat(n)) && isFinite(n);
  }
  if (selection.length > 0) {
    selection.forEach(function (layer) {
      if (layer.shapeType === "Rectangle" || layer.shapeType === "Oval") {
        layer.style.fills = [];
        layer.style.borders = [];
      }
      var startNum = isNumeric(layer.name) ? parseFloat(layer.name) : "false";
      var setting = Settings.layerSettingForKey(layer, 'localConf');
      canvas = {
        layer: layer.id,
        height: layer.frame.height,
        width: layer.frame.width,
        x: layer.frame.x,
        y: layer.frame.y,
        layerType: layer.shapeType,
        startNum: startNum,
        parent: layer.parent.id,
        conf: setting
      };
      canvasArr.push(canvas);
    });
  }
  return [canvasArr, error];
}
function chartUpdatable(context) {
  var sketch = __webpack_require__(/*! sketch */ "sketch"),
    UI = __webpack_require__(/*! sketch/ui */ "sketch/ui"),
    Settings = __webpack_require__(/*! sketch/settings */ "sketch/settings"),
    doc = sketch.getSelectedDocument();
  var selection = doc.selectedLayers,
    updatable = false;
  if (selection.length > 0) {
    selection.forEach(function (layer) {
      var layerConf = Settings.layerSettingForKey(layer, 'localConf');
      if (layerConf != undefined) {
        if (layerConf.data.selected == "random") {
          updatable = true;
        } else if (layerConf.data.selected == "table" && layerConf.data.csv.gsLink != null) {
          updatable = true;
        } else if (layerConf.data.selected == "json" && layerConf.data.json.jsonLink != null) {
          updatable = true;
        }
      }
    });
  } else {
    UI.message('请至少选择一个图层或图表');
  }
  return updatable;
}

// Helper SVG functions






// LABELS
// X/Y 轴独立样式读取（向后兼容旧字段：无 xAxis/yAxis 子对象时回退顶层 fontSize/color）





// Y 轴刻度段数计算（grid.yAxisSegments 控制段数，0=自动 30px 间隔）



// GRIDS



// AXES (轴线 + tick 短线)

// colorPalette index

// Create random data set
function createRandomData(rows, columns, min, max, distr, type) {
  var dataRow = new Array(),
    dataTable = new Array(),
    dataMax = new Array(),
    dataMin = new Array(),
    headers = [];
  function randNum(min, max, col) {
    min = Number(min);
    max = Number(max);
    col = Number(col);
    var data = new Array();
    for (var i = 0; i < col; i++) {
      data[i] = Number(Math.random() * (max - min) + min).toFixed(0);
    }
    return data;
  }
  function trendUp(min, max, col) {
    min = Number(min);
    max = Number(max);
    col = Number(col);
    var step = (max - min) / col,
      data = new Array();
    for (var i = 0; i < col; i++) {
      var tempNum = min + step * (Math.random() * (1.3 - 0.5) + 0.5);
      min += tempNum - min;
      data[i] = tempNum.toFixed(0);
    }
    return data;
  }
  function trendDown(min, max, col) {
    min = Number(min);
    max = Number(max);
    col = Number(col);
    var step = (max - min) / col,
      data = new Array();
    for (var i = 0; i < col; i++) {
      var tempNum = max - step * (Math.random() * (1.3 - 0.5) + 0.5);
      max -= max - tempNum;
      data[i] = tempNum.toFixed(0);
    }
    return data;
  }
  function normalDistr(min, max, col) {
    max = Number(max);
    min = Number(min);
    col = Number(col - 1);
    var data = new Array(),
      originalMax = max;
    for (var i = 0; i <= col; i++) {
      max = max * Math.random();
      var c = min,
        b = 4 * (max - min) / col,
        a = -b / col;
      var tempNum = a * Math.pow(i, 2) + b * i + c;
      data[i] = tempNum.toFixed(0);
      max = originalMax;
    }
    return data;
  }
  var funcArr = [randNum, trendUp, trendDown, normalDistr];
  if (type == "candlestickChart") {
    var newRandom = function newRandom(min, max) {
      return Math.random() * (max - min) + min;
    };
    var range = max - min,
      minTrend = min + newRandom(range * 0.1, range * 0.3),
      maxTrend = max - newRandom(range * 0.1, range * 0.3),
      trendStep = (maxTrend - minTrend) / columns,
      startUp = minTrend,
      startDown = maxTrend,
      centerPoint,
      high,
      close,
      open,
      low,
      delta,
      highArr = new Array(),
      closeArr = new Array(),
      openArr = new Array(),
      lowArr = new Array();
    for (var j = 0; j < columns; j++) {
      if (distr == "1") {
        // Up
        centerPoint = Number(startUp) + trendStep * newRandom(0.7, 1.3);
        startUp = centerPoint;
      } else if (distr == "2") {
        // Down
        centerPoint = Number(startDown) - trendStep * newRandom(0.7, 1.3);
        startDown = centerPoint;
      } else {
        // Noise
        centerPoint = newRandom(range * 0.1, range * 0.9);
      }
      high = centerPoint * newRandom(1.1, 1.3);
      low = centerPoint * newRandom(0.7, 0.9);
      delta = high - low;
      close = newRandom(Number(low) + 0.2 * delta, Number(high) - 0.2 * delta);
      if (close < high - (high - low) / 2) {
        var openDelta = high - close;
        open = newRandom(Number(close) + 0.2 * openDelta, Number(high) - 0.2 * openDelta);
      } else {
        var openDelta = close - low;
        open = newRandom(Number(low) + 0.2 * openDelta, Number(close) - 0.2 * openDelta);
      }
      highArr[j] = high.toFixed(0);
      closeArr[j] = close.toFixed(0);
      openArr[j] = open.toFixed(0);
      lowArr[j] = low.toFixed(0);
    }
    dataTable[0] = highArr;
    dataTable[1] = closeArr;
    dataTable[2] = openArr;
    dataTable[3] = lowArr;
  } else {
    for (var i = 0; i < rows; i++) {
      if (distr == "0") {
        dataRow = randNum(min, max, columns);
      } else if (distr == "1") {
        dataRow = trendUp(min, max, columns);
      } else if (distr == "2") {
        if (type == "scatterPlot" && i == 0) {
          dataRow = trendUp(min, max, columns);
        } else {
          dataRow = trendDown(min, max, columns);
        }
      } else if (distr == "3") {
        if (type == "scatterPlot" && i == 0) {
          dataRow = trendUp(min, max, columns);
        } else {
          dataRow = normalDistr(min, max, columns);
        }
      } else {
        var _randNum = Number(Math.random() * (funcArr.length - 1)).toFixed(0);
        dataRow = funcArr[_randNum](min, max, columns);
      }
      dataTable[i] = dataRow;
      dataMax[i] = Math.max.apply(Math, (0,_babel_runtime_helpers_toConsumableArray__WEBPACK_IMPORTED_MODULE_1__["default"])(dataRow));
      dataMin[i] = Math.min.apply(Math, (0,_babel_runtime_helpers_toConsumableArray__WEBPACK_IMPORTED_MODULE_1__["default"])(dataRow));
    }
  }
  for (var h = 0; h < columns; h++) {
    headers[h] = "Text";
  }
  var dataObj = {
    table: dataTable,
    max: Math.max.apply(Math, dataMax),
    min: Math.min.apply(Math, dataMin),
    rows: dataTable.length,
    columns: dataTable[0].length,
    header: headers
  };
  return dataObj;
}

function parseDataNumber(value) {
  if (value === null || value === undefined) throw new Error('数据中存在空值');
  var original = String(value).trim();
  if (!original) throw new Error('数据中存在空值');
  var text = /%$/.test(original) ? original.slice(0, -1).trim() : original;
  text = text.replace(/^[\$\u00a5\uffe5\u20ac\u00a3]\s*/, '');
  if (/^[+-]?\d{1,3}(,\d{3})+(\.\d+)?(?:[eE][+-]?\d+)?$/.test(text)) text = text.replace(/,/g, '');
  if (!/^[+-]?(?:\d+\.?\d*|\.\d+)(?:[eE][+-]?\d+)?$/.test(text)) throw new Error('无效数字：' + original);
  var number = Number(text);
  if (!isFinite(number)) throw new Error('数字超出可用范围：' + original);
  return number;
}

// Create data set from real data
function processData(csv) {
  function transpose(a) {
    return Object.keys(a[0]).map(function (c) {
      return a.map(function (r) {
        return r[c];
      });
    });
  }
  function isNumeric(n) {
    return !isNaN(parseFloat(n)) && isFinite(n);
  }
  function tableMin(N) {
    var min = new Array();
    for (var i in N) {
      min[i] = Math.min.apply(Math, (0,_babel_runtime_helpers_toConsumableArray__WEBPACK_IMPORTED_MODULE_1__["default"])(N[i]));
    }
    return Math.min.apply(Math, min);
  }
  function tableMax(N) {
    var max = new Array();
    for (var i in N) {
      max[i] = Math.max.apply(Math, (0,_babel_runtime_helpers_toConsumableArray__WEBPACK_IMPORTED_MODULE_1__["default"])(N[i]));
    }
    return Math.max.apply(Math, max);
  }
  var dataObj;
  if (csv.type === null) {
    var col = csv.data[0].length,
      row = csv.data.length,
      newData = csv.data.map(function (dataRow) {
        return dataRow.slice();
      }),
      header;
    if (csv.headers == true) {
      header = newData[0];
      newData.splice(0, 1);
      for (var i = 0; i < row - 1; i++) {
        for (var j = 0; j < col; j++) {
          newData[i][j] = parseDataNumber(newData[i][j]);
        }
      }
      row = row - 1;
    } else {
      header = false;
      for (var _i5 = 0; _i5 < row; _i5++) {
        for (var _j2 = 0; _j2 < col; _j2++) {
          newData[_i5][_j2] = parseDataNumber(newData[_i5][_j2]);
        }
      }
    }
    dataObj = {
      table: newData,
      rows: row,
      columns: col,
      min: tableMin(newData),
      max: tableMax(newData),
      header: header
    };
  } else {
    var _newData = new Array(),
      selectedRows = new Array(),
      headerIndex,
      transposedTable = transpose(csv.data);
    csv.columns.forEach(function (column) {
      if (column.checked) {
        selectedRows.push(column.index);
      }
    });
    selectedRows.forEach(function (row) {
      _newData.push(transposedTable[row]);
    });
    for (var _i6 = 0; _i6 < _newData.length; _i6++) {
      for (var _j3 = 0; _j3 < _newData[0].length; _j3++) {
        _newData[_i6][_j3] = parseDataNumber(_newData[_i6][_j3]);
      }
    }
    csv.header.forEach(function (header) {
      if (header.checked) {
        headerIndex = header.index;
      }
    });
    dataObj = {
      table: _newData,
      rows: _newData.length,
      columns: _newData[0].length,
      min: tableMin(_newData),
      max: tableMax(_newData),
      header: transposedTable[headerIndex]
    };
  }
  log(dataObj);
  return dataObj;
}

// Create data set from JSON
function processJSON(JSON, rawKeys, rawHeader) {
  var keys = new Array(),
    headerKey = "",
    dataTable = new Array(),
    dataMax = new Array(),
    dataMin = new Array();
  function getValues(obj, key) {
    var objects = [];
    for (var i in obj) {
      if (!obj.hasOwnProperty(i)) continue;
      if ((0,_babel_runtime_helpers_typeof__WEBPACK_IMPORTED_MODULE_0__["default"])(obj[i]) == 'object') {
        objects = objects.concat(getValues(obj[i], key));
      } else if (i == key) {
        objects.push(obj[i]);
      }
    }
    return objects;
  }
  rawKeys.forEach(function (key) {
    if (key.checked == true) {
      keys.push(key.name);
    }
  });
  rawHeader.forEach(function (header) {
    if (header.checked == true) {
      headerKey = header.name;
    }
  });
  var headers = getValues(JSON, headerKey);
  for (var i in keys) {
    var row = getValues(JSON, keys[i]);
    for (var j in row) {
      row[j] = parseDataNumber(row[j]);
    }
    dataTable[i] = row;
    dataMax[i] = Math.max.apply(Math, (0,_babel_runtime_helpers_toConsumableArray__WEBPACK_IMPORTED_MODULE_1__["default"])(dataTable[i]));
    dataMin[i] = Math.min.apply(Math, (0,_babel_runtime_helpers_toConsumableArray__WEBPACK_IMPORTED_MODULE_1__["default"])(dataTable[i]));
  }
  var dataObj = {
    table: dataTable,
    max: Math.max.apply(Math, dataMax),
    min: Math.min.apply(Math, dataMin),
    rows: dataTable.length,
    columns: dataTable[0].length,
    header: headers
  };
  return dataObj;
}

// Line chart


// Area chart





// Stacked area chart













function loadXChartSharedModule(fileName, exportName) {
  var bundle = context.command && context.command.pluginBundle ? context.command.pluginBundle() : context.plugin;
  var resource = bundle && bundle.urlForResourceNamed ? bundle.urlForResourceNamed(fileName) : null;
  if (!resource) throw new Error('Missing shared chart resource: ' + fileName);
  var source = String(NSString.stringWithContentsOfFile_encoding_error(resource.path(), NSUTF8StringEncoding, null));
  return eval(source + '\n;' + exportName + ';');
}
function createChart(canvas, configuration) {
  var sharedCore = loadXChartSharedModule('xchart-core.js', 'XChartCore');
  var sharedData = loadXChartSharedModule('xchart-data.js', 'XChartData');
  var sharedAdapter = loadXChartSharedModule('xchart-sketch-adapter.js', 'XChartSketchAdapter');
  var sharedSketch = __webpack_require__(/*! sketch */ "sketch");
  return sharedAdapter.renderCharts({
    core: sharedCore,
    sketch: sharedSketch,
    Settings: __webpack_require__(/*! sketch/settings */ "sketch/settings"),
    document: sharedSketch.getSelectedDocument(),
    canvases: canvas,
    configuration: configuration,
    data: sharedData,
    processors: { createRandomData: createRandomData, processData: processData, processJSON: processJSON }
  });
}

/***/ },

/***/ "./src/nicenum.js"
/*!************************!*\
  !*** ./src/nicenum.js ***!
  \************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   calculateNiceNum: () => (/* binding */ calculateNiceNum)
/* harmony export */ });
function calculateNiceNum(minNum, maxNum, height) {
  // Nice max and min functions
  var minPoint,
    maxPoint,
    maxTicks = 10,
    minStep = 30,
    range,
    tickSpacing,
    niceMin,
    niceMax;
  /**
   * Instantiates a new instance of the NiceScale class.
   *
   *  min the minimum data point on the axis
   *  max the maximum data point on the axis
   */
  function niceScale(min, max) {
    minPoint = Number(min);
    maxPoint = Number(max);
    if (!isFinite(minPoint) || !isFinite(maxPoint)) {
      minPoint = 0;
      maxPoint = 1;
    } else if (minPoint === maxPoint) {
      minPoint -= 1;
      maxPoint += 1;
    }
    calculate();
    if (height != false) {
      var _range = niceMax - niceMin,
        maxNumTicks = Math.max(2, Math.floor(height / minStep)),
        dividers = [0.1, 0.2, 0.5];
      var step = dividers[0],
        numLines = Math.ceil(_range / step),
        i = 0,
        count = 1;
      while (numLines >= maxNumTicks) {
        step = dividers[i] * count;
        numLines = Math.ceil(_range / step);
        if (i === 2) {
          i = 0;
          count = count * 10;
        } else {
          i++;
        }
      }
      niceMax = niceMin + step * numLines;
    }
    return {
      niceMinimum: niceMin,
      niceMaximum: niceMax
    };
  }

  /**
   * Calculate and update values for tick spacing and nice
   * minimum and maximum data points on the axis.
   */
  function calculate() {
    range = niceNum(maxPoint - minPoint, false);
    tickSpacing = niceNum(range / (maxTicks - 1), true);
    niceMin = Math.floor(minPoint / tickSpacing) * tickSpacing;
    niceMax = Math.ceil(maxPoint / tickSpacing) * tickSpacing;
  }

  /**
   * Returns a "nice" number approximately equal to range Rounds
   * the number if round = true Takes the ceiling if round = false.
   *
   *  localRange the data range
   *  round whether to round the result
   *  a "nice" number to be used for the data range
   */
  function niceNum(localRange, round) {
    var exponent; /** exponent of localRange */
    var fraction; /** fractional part of localRange */
    var niceFraction; /** nice, rounded fraction */

    exponent = Math.floor(Math.log10(localRange));
    fraction = localRange / Math.pow(10, exponent);
    if (round) {
      if (fraction < 1.5) niceFraction = 1;else if (fraction < 3) niceFraction = 2;else if (fraction < 7) niceFraction = 5;else niceFraction = 10;
    } else {
      if (fraction <= 1) niceFraction = 1;else if (fraction <= 2) niceFraction = 2;else if (fraction <= 5) niceFraction = 5;else niceFraction = 10;
    }
    return niceFraction * Math.pow(10, exponent);
  }
  return niceScale(minNum, maxNum);
}

/***/ },

/***/ "./node_modules/sketch-polyfill-fetch/lib/index.js"
/*!*********************************************************!*\
  !*** ./node_modules/sketch-polyfill-fetch/lib/index.js ***!
  \*********************************************************/
(module, __unused_webpack_exports, __webpack_require__) {

/* provided dependency */ var Promise = __webpack_require__(/*! ./node_modules/@skpm/promise/index.js */ "./node_modules/@skpm/promise/index.js");
/* globals NSJSONSerialization NSJSONWritingPrettyPrinted NSDictionary NSHTTPURLResponse NSString NSASCIIStringEncoding NSUTF8StringEncoding coscript NSURL NSMutableURLRequest NSMutableData NSURLConnection */
var Buffer;
try {
  Buffer = (__webpack_require__(/*! buffer */ "buffer").Buffer);
} catch (err) {}

function response(httpResponse, data) {
  var keys = [];
  var all = [];
  var headers = {};
  var header;

  for (var i = 0; i < httpResponse.allHeaderFields().allKeys().length; i++) {
    var key = httpResponse
      .allHeaderFields()
      .allKeys()
      [i].toLowerCase();
    var value = String(httpResponse.allHeaderFields()[key]);
    keys.push(key);
    all.push([key, value]);
    header = headers[key];
    headers[key] = header ? header + "," + value : value;
  }

  return {
    ok: ((httpResponse.statusCode() / 200) | 0) == 1, // 200-399
    status: Number(httpResponse.statusCode()),
    statusText: String(
      NSHTTPURLResponse.localizedStringForStatusCode(httpResponse.statusCode())
    ),
    useFinalURL: true,
    url: String(httpResponse.URL().absoluteString()),
    clone: response.bind(this, httpResponse, data),
    text: function() {
      return new Promise(function(resolve, reject) {
        const str = String(
          NSString.alloc().initWithData_encoding(data, NSASCIIStringEncoding)
        );
        if (str) {
          resolve(str);
        } else {
          reject(new Error("Couldn't parse body"));
        }
      });
    },
    json: function() {
      return new Promise(function(resolve, reject) {
        var str = String(
          NSString.alloc().initWithData_encoding(data, NSUTF8StringEncoding)
        );
        if (str) {
          // parse errors are turned into exceptions, which cause promise to be rejected
          var obj = JSON.parse(str);
          resolve(obj);
        } else {
          reject(
            new Error(
              "Could not parse JSON because it is not valid UTF-8 data."
            )
          );
        }
      });
    },
    blob: function() {
      return Promise.resolve(data);
    },
    arrayBuffer: function() {
      return Promise.resolve(Buffer.from(data));
    },
    headers: {
      keys: function() {
        return keys;
      },
      entries: function() {
        return all;
      },
      get: function(n) {
        return headers[n.toLowerCase()];
      },
      has: function(n) {
        return n.toLowerCase() in headers;
      }
    }
  };
}

// We create one ObjC class for ourselves here
var DelegateClass;

function fetch(urlString, options) {
  if (
    typeof urlString === "object" &&
    (!urlString.isKindOfClass || !urlString.isKindOfClass(NSString))
  ) {
    options = urlString;
    urlString = options.url;
  }
  options = options || {};
  if (!urlString) {
    return Promise.reject("Missing URL");
  }
  var fiber;
  try {
    fiber = coscript.createFiber();
  } catch (err) {
    coscript.shouldKeepAround = true;
  }
  return new Promise(function(resolve, reject) {
    var url = NSURL.alloc().initWithString(urlString);
    var request = NSMutableURLRequest.requestWithURL(url);
    request.setHTTPMethod(options.method || "GET");

    Object.keys(options.headers || {}).forEach(function(i) {
      request.setValue_forHTTPHeaderField(options.headers[i], i);
    });

    if (options.body) {
      var data;
      if (typeof options.body === "string") {
        var str = NSString.alloc().initWithString(options.body);
        data = str.dataUsingEncoding(NSUTF8StringEncoding);
      } else if (Buffer && Buffer.isBuffer(options.body)) {
        data = options.body.toNSData();
      } else if (
        options.body.isKindOfClass &&
        options.body.isKindOfClass(NSData) == 1
      ) {
        data = options.body;
      } else if (options.body._isFormData) {
        var boundary = options.body._boundary;
        data = options.body._data;
        data.appendData(
          NSString.alloc()
            .initWithString("--" + boundary + "--\r\n")
            .dataUsingEncoding(NSUTF8StringEncoding)
        );
        request.setValue_forHTTPHeaderField(
          "multipart/form-data; boundary=" + boundary,
          "Content-Type"
        );
      } else {
        var exception;
        data = NSJSONSerialization.dataWithJSONObject_options_error(
          options.body,
          NSJSONWritingPrettyPrinted,
          exception
        );
        if (exception != null) {
          var error = new TypeError(
            String(
              typeof exception.localizedDescription === "function"
                ? exception.localizedDescription()
                : exception
            )
          );
          reject(error);
          return;
        }
        request.setValue_forHTTPHeaderField(
          "" + data.length(),
          "Content-Length"
        );
      }
      request.setHTTPBody(data);
    }

    if (options.cache) {
      switch (options.cache) {
        case "reload":
        case "no-cache":
        case "no-store": {
          request.setCachePolicy(1); // NSURLRequestReloadIgnoringLocalCacheData
          break;
        }
        case "force-cache": {
          request.setCachePolicy(2); // NSURLRequestReturnCacheDataElseLoad
          break;
        }
        case "only-if-cached": {
          request.setCachePolicy(3); // NSURLRequestReturnCacheDataElseLoad
          break;
        }
      }
    }

    if (!options.credentials) {
      request.setHTTPShouldHandleCookies(false);
    }

    var finished = false;

    var connection = NSURLSession.sharedSession().dataTaskWithRequest_completionHandler(
      request,
      __mocha__.createBlock_function(
        'v32@?0@"NSData"8@"NSURLResponse"16@"NSError"24',
        function(data, res, exception) {
          if (fiber) {
            fiber.cleanup();
          } else {
            coscript.shouldKeepAround = false;
          }
          finished = true;
          try {
            if (exception) {
              var error = new TypeError(
                String(
                  typeof exception.localizedDescription === "function"
                    ? exception.localizedDescription()
                    : exception
                )
              );
              reject(error);
              return;
            }
            resolve(response(res, data));
          } catch (err) {
            reject(err);
          }
        }
      )
    );

    connection.resume();

    if (fiber) {
      fiber.onCleanup(function() {
        if (!finished) {
          connection.cancel();
        }
      });
    }
  });
}

module.exports = fetch;


/***/ },

/***/ "buffer"
/*!*************************!*\
  !*** external "buffer" ***!
  \*************************/
(module) {

"use strict";
module.exports = require("buffer");

/***/ },

/***/ "sketch"
/*!*************************!*\
  !*** external "sketch" ***!
  \*************************/
(module) {

"use strict";
module.exports = require("sketch");

/***/ },

/***/ "sketch/dom"
/*!*****************************!*\
  !*** external "sketch/dom" ***!
  \*****************************/
(module) {

"use strict";
module.exports = require("sketch/dom");

/***/ },

/***/ "sketch/settings"
/*!**********************************!*\
  !*** external "sketch/settings" ***!
  \**********************************/
(module) {

"use strict";
module.exports = require("sketch/settings");

/***/ },

/***/ "sketch/ui"
/*!****************************!*\
  !*** external "sketch/ui" ***!
  \****************************/
(module) {

"use strict";
module.exports = require("sketch/ui");

/***/ },

/***/ "./node_modules/@babel/runtime/helpers/esm/arrayLikeToArray.js"
/*!*********************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/esm/arrayLikeToArray.js ***!
  \*********************************************************************/
(__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ _arrayLikeToArray)
/* harmony export */ });
function _arrayLikeToArray(r, a) {
  (null == a || a > r.length) && (a = r.length);
  for (var e = 0, n = Array(a); e < a; e++) n[e] = r[e];
  return n;
}


/***/ },

/***/ "./node_modules/@babel/runtime/helpers/esm/arrayWithoutHoles.js"
/*!**********************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/esm/arrayWithoutHoles.js ***!
  \**********************************************************************/
(__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ _arrayWithoutHoles)
/* harmony export */ });
/* harmony import */ var _arrayLikeToArray_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./arrayLikeToArray.js */ "./node_modules/@babel/runtime/helpers/esm/arrayLikeToArray.js");

function _arrayWithoutHoles(r) {
  if (Array.isArray(r)) return (0,_arrayLikeToArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(r);
}


/***/ },

/***/ "./node_modules/@babel/runtime/helpers/esm/iterableToArray.js"
/*!********************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/esm/iterableToArray.js ***!
  \********************************************************************/
(__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ _iterableToArray)
/* harmony export */ });
function _iterableToArray(r) {
  if ("undefined" != typeof Symbol && null != r[Symbol.iterator] || null != r["@@iterator"]) return Array.from(r);
}


/***/ },

/***/ "./node_modules/@babel/runtime/helpers/esm/nonIterableSpread.js"
/*!**********************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/esm/nonIterableSpread.js ***!
  \**********************************************************************/
(__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ _nonIterableSpread)
/* harmony export */ });
function _nonIterableSpread() {
  throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}


/***/ },

/***/ "./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js"
/*!**********************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js ***!
  \**********************************************************************/
(__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ _toConsumableArray)
/* harmony export */ });
/* harmony import */ var _arrayWithoutHoles_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./arrayWithoutHoles.js */ "./node_modules/@babel/runtime/helpers/esm/arrayWithoutHoles.js");
/* harmony import */ var _iterableToArray_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./iterableToArray.js */ "./node_modules/@babel/runtime/helpers/esm/iterableToArray.js");
/* harmony import */ var _unsupportedIterableToArray_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./unsupportedIterableToArray.js */ "./node_modules/@babel/runtime/helpers/esm/unsupportedIterableToArray.js");
/* harmony import */ var _nonIterableSpread_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./nonIterableSpread.js */ "./node_modules/@babel/runtime/helpers/esm/nonIterableSpread.js");




function _toConsumableArray(r) {
  return (0,_arrayWithoutHoles_js__WEBPACK_IMPORTED_MODULE_0__["default"])(r) || (0,_iterableToArray_js__WEBPACK_IMPORTED_MODULE_1__["default"])(r) || (0,_unsupportedIterableToArray_js__WEBPACK_IMPORTED_MODULE_2__["default"])(r) || (0,_nonIterableSpread_js__WEBPACK_IMPORTED_MODULE_3__["default"])();
}


/***/ },

/***/ "./node_modules/@babel/runtime/helpers/esm/typeof.js"
/*!***********************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/esm/typeof.js ***!
  \***********************************************************/
(__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ _typeof)
/* harmony export */ });
function _typeof(o) {
  "@babel/helpers - typeof";

  return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) {
    return typeof o;
  } : function (o) {
    return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
  }, _typeof(o);
}


/***/ },

/***/ "./node_modules/@babel/runtime/helpers/esm/unsupportedIterableToArray.js"
/*!*******************************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/esm/unsupportedIterableToArray.js ***!
  \*******************************************************************************/
(__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ _unsupportedIterableToArray)
/* harmony export */ });
/* harmony import */ var _arrayLikeToArray_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./arrayLikeToArray.js */ "./node_modules/@babel/runtime/helpers/esm/arrayLikeToArray.js");

function _unsupportedIterableToArray(r, a) {
  if (r) {
    if ("string" == typeof r) return (0,_arrayLikeToArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(r, a);
    var t = {}.toString.call(r).slice(8, -1);
    return "Object" === t && r.constructor && (t = r.constructor.name), "Map" === t || "Set" === t ? Array.from(r) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? (0,_arrayLikeToArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(r, a) : void 0;
  }
}


/***/ }

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	const __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		const cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		const module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		if (!(moduleId in __webpack_modules__)) {
/******/ 			delete __webpack_module_cache__[moduleId];
/******/ 			const e = new Error("Cannot find module '" + moduleId + "'");
/******/ 			e.code = 'MODULE_NOT_FOUND';
/******/ 			throw e;
/******/ 		}
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/define property getters */
/******/ 	// define getter/value functions for harmony exports
/******/ 	__webpack_require__.d = (exports, definition) => {
/******/ 		for(var key in definition) {
/******/ 			if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 				Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 			}
/******/ 		}
/******/ 	};
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop));
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = (exports) => {
/******/ 		Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/ 	
/************************************************************************/
let __webpack_exports__ = {};
// This entry needs to be wrapped in an IIFE because it needs to be in strict mode.
(() => {
"use strict";
/*!***********************!*\
  !*** ./src/update.js ***!
  \***********************/
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* export default binding */ __WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _common__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./common */ "./src/common.js");

function xchartIsObject(value) {
  return value !== null && typeof value === 'object' && !Array.isArray(value);
}
function xchartClone(value) {
  return value === undefined ? undefined : JSON.parse(JSON.stringify(value));
}
function xchartMerge(base, overrides) {
  if (overrides === undefined) return xchartClone(base);
  if (Array.isArray(overrides) || !xchartIsObject(overrides)) return xchartClone(overrides);
  var output = xchartIsObject(base) ? xchartClone(base) : {};
  Object.keys(overrides).forEach(function (key) {
    output[key] = xchartIsObject(overrides[key]) ? xchartMerge(output[key], overrides[key]) : xchartClone(overrides[key]);
  });
  return output;
}
function xchartTemplateSettings(template) {
  var output = {};
  Object.keys(template || {}).forEach(function (key) {
    if (key !== 'id' && key !== 'name' && key !== 'updatable') output[key] = xchartClone(template[key]);
  });
  return output;
}
function xchartEqual(left, right) {
  return JSON.stringify(left) === JSON.stringify(right);
}
function xchartDiff(template, settings) {
  var base = xchartTemplateSettings(template), current = xchartTemplateSettings(settings), output = {};
  Object.keys(current).forEach(function (key) {
    if (xchartEqual(base[key], current[key])) return;
    if (xchartIsObject(base[key]) && xchartIsObject(current[key])) {
      var nested = xchartDiff(base[key], current[key]);
      if (Object.keys(nested).length) output[key] = nested;
    } else output[key] = xchartClone(current[key]);
  });
  return output;
}
function xchartResolveLinkedConfig(conf, templates) {
  conf = conf || {};
  var settings = conf.settings || {};
  var ref = conf.templateRef || { id: settings.id, mode: settings.updatable === true ? 'linked' : 'frozen', revision: 1 };
  if (ref.mode !== 'linked') return conf;
  var template = null;
  (templates || []).forEach(function (candidate) {
    if (String(candidate.id) === String(ref.id)) template = candidate;
  });
  if (!template) {
    ref.mode = 'detached';
    conf.templateRef = ref;
    settings.updatable = false;
    return conf;
  }
  if (conf.schemaVersion !== 2 || !conf.overrides) conf.overrides = xchartDiff(template, settings);
  conf.schemaVersion = 2;
  conf.templateRef = { id: template.id, mode: 'linked', revision: Number(ref.revision) || 1 };
  conf.settings = xchartMerge(xchartTemplateSettings(template), conf.overrides);
  conf.settings.id = template.id;
  conf.settings.name = template.name;
  conf.settings.updatable = true;
  return conf;
}

/* harmony default export */ function __WEBPACK_DEFAULT_EXPORT__(context) {
  var Settings = __webpack_require__(/*! sketch/settings */ "sketch/settings"),
    UI = __webpack_require__(/*! sketch/ui */ "sketch/ui"),
    fetch = __webpack_require__(/*! sketch-polyfill-fetch */ "./node_modules/sketch-polyfill-fetch/lib/index.js"),
    sketch = __webpack_require__(/*! sketch */ "sketch"),
    doc = sketch.getSelectedDocument();
  var chartRoots = [];
  doc.selectedLayers.forEach(function (layer) {
    var current = layer,
      root = null,
      guard = 0;
    while (current && guard < 40) {
      if (Settings.layerSettingForKey(current, 'localConf') !== undefined) {
        root = current;
        break;
      }
      current = current.parent;
      guard += 1;
    }
    if (root && !chartRoots.some(function (item) {
      return item.id === root.id;
    })) chartRoots.push(root);
  });
  var canvas = chartRoots.map(function (layer) {
    return {
      layer: layer.id,
      height: layer.frame.height,
      width: layer.frame.width,
      x: layer.frame.x,
      y: layer.frame.y,
      layerType: layer.shapeType,
      startNum: 'false',
      parent: layer.parent.id,
      conf: Settings.layerSettingForKey(layer, 'localConf')
    };
  });
  if (canvas.length > 0) {
	    canvas.forEach(function (canvas) {
	      var templates = JSON.parse(Settings.globalSettingForKey('xchart.templates') || '[]');
	      canvas.conf = xchartResolveLinkedConfig(canvas.conf, templates);
      if (canvas.conf.data.selected == "table" && canvas.conf.data.csv.type == "google") {
        var legacyCsv = canvas.conf.data.csv;
        var cachedRows = Array.isArray(legacyCsv.data) ? legacyCsv.data : [];
        var selectedColumns = (legacyCsv.columns || []).filter(function (column) {
          return column.checked;
        });
        var selectedHeader = (legacyCsv.header || []).find(function (header) {
          return header.checked;
        });
        var labels = cachedRows.map(function (row, index) {
          return selectedHeader && Array.isArray(row) ? row[selectedHeader.index] : String(index + 1);
        });
        var manualData = [labels].concat(selectedColumns.map(function (column) {
          return cachedRows.map(function (row) {
            return Array.isArray(row) ? row[column.index] : '';
          });
        }));
        canvas.conf.data.csv = {
          name: null,
          type: null,
          data: manualData,
          headers: true,
          columns: [],
          header: []
        };
        var finalCanvas = [canvas];
        (0,_common__WEBPACK_IMPORTED_MODULE_0__.createChart)(finalCanvas, canvas.conf);
        UI.message('外部表格同步已移除，已使用图表中保存的数据');
      } else if (canvas.conf.data.selected == "json" && canvas.conf.data.json.jsonLink != null) {
        UI.message('正在获取数据...');
        fetch(canvas.conf.data.json.jsonLink).then(function (res) {
          if (res.status && (res.status < 200 || res.status >= 300)) throw new Error('HTTP ' + res.status);
          return res.json();
        }).then(function (jsonData) {
          canvas.conf.data.json.data = jsonData;
          var finalCanvas = [canvas];
          (0,_common__WEBPACK_IMPORTED_MODULE_0__.createChart)(finalCanvas, canvas.conf);
          UI.message('图表已更新');
        }).catch(function (error) {
          UI.message('更新失败：' + error.message);
        });
      } else {
        var finalCanvas = [canvas];
        log(canvas.conf);
        (0,_common__WEBPACK_IMPORTED_MODULE_0__.createChart)(finalCanvas, canvas.conf);
        UI.message('图表已更新');
      }
    });
  } else if (doc.selectedLayers.length === 0) {
    UI.message('请先选择一个图表或图表中的图层');
  } else {
    UI.message('所选内容不是可更新的 X-Chart 图表');
  }
}
})();

exports = __webpack_exports__;
/******/ })()
;
    if (key === 'default' && typeof exports === 'function') {
      exports(context);
    } else if (typeof exports[key] !== 'function') {
      throw new Error('Missing export named "' + key + '". Your command should contain something like `export function " + key +"() {}`.');
    } else {
      exports[key](context);
    }
  } catch (err) {
    if (typeof process !== 'undefined' && process.listenerCount && process.listenerCount('uncaughtException')) {
      process.emit("uncaughtException", err, "uncaughtException");
    } else {
      throw err
    }
  }
}
globalThis['onRun'] = __skpm_run.bind(this, 'default')
