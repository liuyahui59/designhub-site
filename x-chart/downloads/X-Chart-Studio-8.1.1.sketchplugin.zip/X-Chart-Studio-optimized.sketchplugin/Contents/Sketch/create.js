var globalThis = this;
var global = this;
function __skpm_run (key, context) {
  globalThis.context = context;
  try {

var exports;
/******/ (() => { // webpackBootstrap
/******/ 	var __webpack_modules__ = ({

/***/ "./node_modules/@skpm/dialog/lib/index.js"
/*!************************************************!*\
  !*** ./node_modules/@skpm/dialog/lib/index.js ***!
  \************************************************/
(module, __unused_webpack_exports, __webpack_require__) {

/* let's try to match the API from Electron's Dialog
(https://github.com/electron/electron/blob/master/docs/api/dialog.md) */

module.exports = {
  showOpenDialog: (__webpack_require__(/*! ./open-dialog */ "./node_modules/@skpm/dialog/lib/open-dialog.js").openDialog),
  showOpenDialogSync: (__webpack_require__(/*! ./open-dialog */ "./node_modules/@skpm/dialog/lib/open-dialog.js").openDialogSync),
  showSaveDialog: (__webpack_require__(/*! ./save-dialog */ "./node_modules/@skpm/dialog/lib/save-dialog.js").saveDialog),
  showSaveDialogSync: (__webpack_require__(/*! ./save-dialog */ "./node_modules/@skpm/dialog/lib/save-dialog.js").saveDialogSync),
  showMessageBox: (__webpack_require__(/*! ./message-box */ "./node_modules/@skpm/dialog/lib/message-box.js").messageBox),
  showMessageBoxSync: (__webpack_require__(/*! ./message-box */ "./node_modules/@skpm/dialog/lib/message-box.js").messageBoxSync),
  // showErrorBox: require('./error-box'),
}


/***/ },

/***/ "./node_modules/@skpm/dialog/lib/message-box.js"
/*!******************************************************!*\
  !*** ./node_modules/@skpm/dialog/lib/message-box.js ***!
  \******************************************************/
(module, __unused_webpack_exports, __webpack_require__) {

/* eslint-disable no-not-accumulator-reassign/no-not-accumulator-reassign */
var utils = __webpack_require__(/*! ./utils */ "./node_modules/@skpm/dialog/lib/utils.js")

var typeMap = {
  none: 0,
  info: 1,
  error: 2,
  question: 1,
  warning: 2,
}

function setupOptions(document, options) {
  if (
    !document ||
    (typeof document.isKindOfClass !== 'function' && !document.sketchObject)
  ) {
    options = document
    document = undefined
  } else if (document.sketchObject) {
    document = document.sketchObject
  }
  if (!options) {
    options = {}
  }

  var dialog = NSAlert.alloc().init()

  if (options.type) {
    dialog.alertStyle = typeMap[options.type] || 0
  }

  if (options.buttons && options.buttons.length) {
    options.buttons.forEach(function addButton(button) {
      dialog.addButtonWithTitle(
        options.normalizeAccessKeys ? button.replace(/&/g, '') : button
      )
      // TODO: add keyboard shortcut if options.normalizeAccessKeys
    })
  }

  if (typeof options.defaultId !== 'undefined') {
    var buttons = dialog.buttons()
    if (options.defaultId < buttons.length) {
      // Focus the button at defaultId if the user opted to do so.
      // The first button added gets set as the default selected.
      // So remove that default, and make the requested button the default.
      buttons[0].setKeyEquivalent('')
      buttons[options.defaultId].setKeyEquivalent('\r')
    }
  }

  if (options.title) {
    // not shown on macOS
  }

  if (options.message) {
    dialog.messageText = options.message
  }

  if (options.detail) {
    dialog.informativeText = options.detail
  }

  if (options.checkboxLabel) {
    dialog.showsSuppressionButton = true
    dialog.suppressionButton().title = options.checkboxLabel

    if (typeof options.checkboxChecked !== 'undefined') {
      dialog.suppressionButton().state = options.checkboxChecked
        ? NSOnState
        : NSOffState
    }
  }

  if (options.icon) {
    if (typeof options.icon === 'string') {
      options.icon = NSImage.alloc().initWithContentsOfFile(options.icon)
    }
    dialog.icon = options.icon
  } else if (
    typeof __command !== 'undefined' &&
    __command.pluginBundle() &&
    __command.pluginBundle().icon()
  ) {
    dialog.icon = __command.pluginBundle().icon()
  } else {
    var icon = NSImage.imageNamed('plugins')
    if (icon) {
      dialog.icon = icon
    }
  }

  return {
    document: document,
    options: options,
    dialog: dialog,
  }
}

// https://github.com/electron/electron/blob/master/docs/api/dialog.md#dialogshowmessageboxbrowserwindow-options
module.exports.messageBox = function messageBox(document, options) {
  var setup = setupOptions(document, options)

  return utils.runDialog(
    setup.dialog,
    function getResult(_dialog, returnCode) {
      return {
        response:
          setup.options.buttons && setup.options.buttons.length
            ? Number(returnCode) - 1000
            : Number(returnCode),
        checkboxChecked: _dialog.suppressionButton().state() == NSOnState,
      }
    },
    setup.document
  )
}

// https://github.com/electron/electron/blob/master/docs/api/dialog.md#dialogshowmessageboxsyncbrowserwindow-options
module.exports.messageBoxSync = function messageBoxSync(document, options) {
  var setup = setupOptions(document, options)

  return utils.runDialogSync(
    setup.dialog,
    function getResult(_dialog, returnCode) {
      return setup.options.buttons && setup.options.buttons.length
        ? Number(returnCode) - 1000
        : Number(returnCode)
    },
    setup.document
  )
}


/***/ },

/***/ "./node_modules/@skpm/dialog/lib/open-dialog.js"
/*!******************************************************!*\
  !*** ./node_modules/@skpm/dialog/lib/open-dialog.js ***!
  \******************************************************/
(module, __unused_webpack_exports, __webpack_require__) {

/* eslint-disable no-not-accumulator-reassign/no-not-accumulator-reassign */
var utils = __webpack_require__(/*! ./utils */ "./node_modules/@skpm/dialog/lib/utils.js")

function setupOptions(document, options) {
  if (
    !document ||
    (typeof document.isKindOfClass !== 'function' && !document.sketchObject)
  ) {
    options = document
    document = undefined
  }
  if (!options) {
    options = {}
  }

  var dialog = NSOpenPanel.openPanel()

  if (options.title) {
    dialog.title = options.title
  }

  if (options.defaultPath) {
    dialog.setDirectoryURL(utils.getURL(options.defaultPath))
  }

  if (options.buttonLabel) {
    dialog.prompt = options.buttonLabel
  }

  if (options.filters && options.filters.length) {
    var exts = []
    options.filters.forEach(function setFilter(filter) {
      filter.extensions.forEach(function setExtension(ext) {
        exts.push(ext)
      })
    })

    dialog.allowedFileTypes = exts
  }

  var hasProperty =
    Array.isArray(options.properties) && options.properties.length > 0
  dialog.canChooseFiles =
    hasProperty && options.properties.indexOf('openFile') !== -1
  dialog.canChooseDirectories =
    hasProperty && options.properties.indexOf('openDirectory') !== -1
  dialog.allowsMultipleSelection =
    hasProperty && options.properties.indexOf('multiSelections') !== -1
  dialog.showsHiddenFiles =
    hasProperty && options.properties.indexOf('showHiddenFiles') !== -1
  dialog.canCreateDirectories =
    hasProperty && options.properties.indexOf('createDirectory') !== -1
  dialog.resolvesAliases =
    !hasProperty || options.properties.indexOf('noResolveAliases') === -1
  dialog.treatsFilePackagesAsDirectories =
    hasProperty && options.properties.indexOf('treatPackageAsDirectory') !== -1

  if (options.message) {
    dialog.message = options.message
  }

  return {
    document: document,
    options: options,
    dialog: dialog,
  }
}

// https://github.com/electron/electron/blob/master/docs/api/dialog.md#dialogshowopendialogbrowserwindow-options
module.exports.openDialog = function openDialog(document, options) {
  var setup = setupOptions(document, options)

  return utils.runDialog(
    setup.dialog,
    function getResult(_dialog, returnCode) {
      if (returnCode != NSOKButton) {
        return {
          canceled: true,
          filePaths: [],
        }
      }
      var result = []
      var urls = _dialog.URLs()
      for (var k = 0; k < urls.length; k += 1) {
        result.push(String(urls[k].path()))
      }
      return {
        canceled: false,
        filePaths: result,
      }
    },
    setup.document
  )
}

// https://github.com/electron/electron/blob/master/docs/api/dialog.md#dialogshowopendialogsyncbrowserwindow-options
module.exports.openDialogSync = function openDialogSync(document, options) {
  var setup = setupOptions(document, options)

  return utils.runDialogSync(
    setup.dialog,
    function getResult(_dialog, returnCode) {
      if (returnCode != NSOKButton) {
        return []
      }
      var result = []
      var urls = _dialog.URLs()
      for (var k = 0; k < urls.length; k += 1) {
        result.push(String(urls[k].path()))
      }
      return result
    },
    setup.document
  )
}


/***/ },

/***/ "./node_modules/@skpm/dialog/lib/save-dialog.js"
/*!******************************************************!*\
  !*** ./node_modules/@skpm/dialog/lib/save-dialog.js ***!
  \******************************************************/
(module, __unused_webpack_exports, __webpack_require__) {

/* eslint-disable no-not-accumulator-reassign/no-not-accumulator-reassign */
var utils = __webpack_require__(/*! ./utils */ "./node_modules/@skpm/dialog/lib/utils.js")

function setupOptions(document, options) {
  if (
    !document ||
    (typeof document.isKindOfClass !== 'function' && !document.sketchObject)
  ) {
    options = document
    document = undefined
  }
  if (!options) {
    options = {}
  }

  var dialog = NSSavePanel.savePanel()

  if (options.title) {
    dialog.title = options.title
  }

  if (options.defaultPath) {
    // that's a path
    dialog.setDirectoryURL(utils.getURL(options.defaultPath))

    if (
      options.defaultPath[0] === '.' ||
      options.defaultPath[0] === '~' ||
      options.defaultPath[0] === '/'
    ) {
      var parts = options.defaultPath.split('/')
      if (parts.length > 1 && parts[parts.length - 1]) {
        dialog.setNameFieldStringValue(parts[parts.length - 1])
      }
    } else {
      dialog.setNameFieldStringValue(options.defaultPath)
    }
  }

  if (options.buttonLabel) {
    dialog.prompt = options.buttonLabel
  }

  if (options.filters && options.filters.length) {
    var exts = []
    options.filters.forEach(function setFilter(filter) {
      filter.extensions.forEach(function setExtension(ext) {
        exts.push(ext)
      })
    })

    if (dialog.allowedContentTypes) {
      // Big Sur and newer.
      dialog.allowedContentTypes = exts.map((ext) => UTType.typeWithFilenameExtension(ext))
    } else {
      // Catalina and older.
      dialog.allowedFileTypes = exts
    }
  }

  if (options.message) {
    dialog.message = options.message
  }

  if (options.nameFieldLabel) {
    dialog.nameFieldLabel = options.nameFieldLabel
  }

  if (options.showsTagField) {
    dialog.showsTagField = options.showsTagField
  }

  return {
    document: document,
    options: options,
    dialog: dialog,
  }
}

// https://github.com/electron/electron/blob/master/docs/api/dialog.md#dialogshowsavedialogbrowserwindow-options
module.exports.saveDialog = function saveDialog(document, options) {
  var setup = setupOptions(document, options)

  return utils.runDialog(
    setup.dialog,
    function getResult(_dialog, returnCode) {
      return {
        canceled: returnCode != NSOKButton,
        filePath:
          returnCode == NSOKButton ? String(_dialog.URL().path()) : undefined,
      }
    },
    setup.document
  )
}

// https://github.com/electron/electron/blob/master/docs/api/dialog.md#dialogshowsavedialogsyncbrowserwindow-options
module.exports.saveDialogSync = function saveDialogSync(document, options) {
  var setup = setupOptions(document, options)

  return utils.runDialogSync(
    setup.dialog,
    function getResult(_dialog, returnCode) {
      return returnCode == NSOKButton ? String(_dialog.URL().path()) : undefined
    },
    setup.document
  )
}


/***/ },

/***/ "./node_modules/@skpm/dialog/lib/utils.js"
/*!************************************************!*\
  !*** ./node_modules/@skpm/dialog/lib/utils.js ***!
  \************************************************/
(module, __unused_webpack_exports, __webpack_require__) {

/* provided dependency */ var Promise = __webpack_require__(/*! ./node_modules/@skpm/promise/index.js */ "./node_modules/@skpm/promise/index.js");
module.exports.getURL = function getURL(path) {
  return NSURL.URLWithString(
    String(
      NSString.stringWithString(path).stringByExpandingTildeInPath()
    ).replace(/ /g, '%20')
  )
}

module.exports.runDialog = function runDialog(dialog, getResult, document) {
  if (!document) {
    var returnCode = dialog.runModal()
    return Promise.resolve(getResult(dialog, returnCode))
  }

  var fiber = coscript.createFiber()

  var window = (document.sketchObject || document).documentWindow()

  return new Promise(function p(resolve, reject) {
    dialog.beginSheetModalForWindow_completionHandler(
      window,
      __mocha__.createBlock_function('v16@?0q8', function onCompletion(
        _returnCode
      ) {
        try {
          resolve(getResult(dialog, _returnCode))
        } catch (err) {
          reject(err)
        }
        NSApp.endSheet(dialog)
        if (fiber) {
          fiber.cleanup()
        } else {
          coscript.shouldKeepAround = false
        }
      })
    )
  })
}

module.exports.runDialogSync = function runDialog(dialog, getResult, document) {
  var returnCode

  if (!document) {
    returnCode = dialog.runModal()
    return getResult(dialog, returnCode)
  }

  var window = (document.sketchObject || document).documentWindow()

  dialog.beginSheetModalForWindow_completionHandler(
    window,
    __mocha__.createBlock_function('v16@?0q8', function onCompletion(
      _returnCode
    ) {
      NSApp.stopModalWithCode(_returnCode)
    })
  )

  returnCode = NSApp.runModalForWindow(window)
  NSApp.endSheet(dialog)
  return getResult(dialog, returnCode)
}


/***/ },

/***/ "./assets/createChart.html"
/*!*********************************!*\
  !*** ./assets/createChart.html ***!
  \*********************************/
(module) {

module.exports = "file://" + String(context.scriptPath).split(".sketchplugin/Contents/Sketch")[0] + ".sketchplugin/Contents/Resources/createChart.html";

/***/ },

/***/ "./node_modules/@skpm/promise/index.js"
/*!*********************************************!*\
  !*** ./node_modules/@skpm/promise/index.js ***!
  \*********************************************/
(module) {

/* from https://github.com/taylorhakes/promise-polyfill */

function promiseFinally(callback) {
  var constructor = this.constructor;
  return this.then(
    function(value) {
      return constructor.resolve(callback()).then(function() {
        return value;
      });
    },
    function(reason) {
      return constructor.resolve(callback()).then(function() {
        return constructor.reject(reason);
      });
    }
  );
}

function noop() {}

/**
 * @constructor
 * @param {Function} fn
 */
function Promise(fn) {
  if (!(this instanceof Promise))
    throw new TypeError("Promises must be constructed via new");
  if (typeof fn !== "function") throw new TypeError("not a function");
  /** @type {!number} */
  this._state = 0;
  /** @type {!boolean} */
  this._handled = false;
  /** @type {Promise|undefined} */
  this._value = undefined;
  /** @type {!Array<!Function>} */
  this._deferreds = [];

  doResolve(fn, this);
}

function handle(self, deferred) {
  while (self._state === 3) {
    self = self._value;
  }
  if (self._state === 0) {
    self._deferreds.push(deferred);
    return;
  }
  self._handled = true;
  Promise._immediateFn(function() {
    var cb = self._state === 1 ? deferred.onFulfilled : deferred.onRejected;
    if (cb === null) {
      (self._state === 1 ? resolve : reject)(deferred.promise, self._value);
      return;
    }
    var ret;
    try {
      ret = cb(self._value);
    } catch (e) {
      reject(deferred.promise, e);
      return;
    }
    resolve(deferred.promise, ret);
  });
}

function resolve(self, newValue) {
  try {
    // Promise Resolution Procedure: https://github.com/promises-aplus/promises-spec#the-promise-resolution-procedure
    if (newValue === self)
      throw new TypeError("A promise cannot be resolved with itself.");
    if (
      newValue &&
      (typeof newValue === "object" || typeof newValue === "function")
    ) {
      var then = newValue.then;
      if (newValue instanceof Promise) {
        self._state = 3;
        self._value = newValue;
        finale(self);
        return;
      } else if (typeof then === "function") {
        doResolve(then.bind(newValue), self);
        return;
      }
    }
    self._state = 1;
    self._value = newValue;
    finale(self);
  } catch (e) {
    reject(self, e);
  }
}

function reject(self, newValue) {
  self._state = 2;
  self._value = newValue;
  finale(self);
}

function finale(self) {
  if (self._state === 2 && self._deferreds.length === 0) {
    Promise._immediateFn(function() {
      if (!self._handled) {
        Promise._unhandledRejectionFn(self._value, self);
      }
    });
  }

  for (var i = 0, len = self._deferreds.length; i < len; i++) {
    handle(self, self._deferreds[i]);
  }
  self._deferreds = null;
}

/**
 * @constructor
 */
function Handler(onFulfilled, onRejected, promise) {
  this.onFulfilled = typeof onFulfilled === "function" ? onFulfilled : null;
  this.onRejected = typeof onRejected === "function" ? onRejected : null;
  this.promise = promise;
}

/**
 * Take a potentially misbehaving resolver function and make sure
 * onFulfilled and onRejected are only called once.
 *
 * Makes no guarantees about asynchrony.
 */
function doResolve(fn, self) {
  var done = false;
  try {
    fn(
      function(value) {
        if (done) {
          Promise._multipleResolvesFn("resolve", self, value);
          return;
        }
        done = true;
        resolve(self, value);
      },
      function(reason) {
        if (done) {
          Promise._multipleResolvesFn("reject", self, reason);
          return;
        }
        done = true;
        reject(self, reason);
      }
    );
  } catch (ex) {
    if (done) {
      Promise._multipleResolvesFn("reject", self, ex);
      return;
    }
    done = true;
    reject(self, ex);
  }
}

Promise.prototype["catch"] = function(onRejected) {
  return this.then(null, onRejected);
};

Promise.prototype.then = function(onFulfilled, onRejected) {
  // @ts-ignore
  var prom = new this.constructor(noop);

  handle(this, new Handler(onFulfilled, onRejected, prom));
  return prom;
};

Promise.prototype["finally"] = promiseFinally;

Promise.all = function(arr) {
  return new Promise(function(resolve, reject) {
    if (!Array.isArray(arr)) {
      return reject(new TypeError("Promise.all accepts an array"));
    }

    var args = Array.prototype.slice.call(arr);
    if (args.length === 0) return resolve([]);
    var remaining = args.length;

    function res(i, val) {
      try {
        if (val && (typeof val === "object" || typeof val === "function")) {
          var then = val.then;
          if (typeof then === "function") {
            then.call(
              val,
              function(val) {
                res(i, val);
              },
              reject
            );
            return;
          }
        }
        args[i] = val;
        if (--remaining === 0) {
          resolve(args);
        }
      } catch (ex) {
        reject(ex);
      }
    }

    for (var i = 0; i < args.length; i++) {
      res(i, args[i]);
    }
  });
};

Promise.resolve = function(value) {
  if (value && typeof value === "object" && value.constructor === Promise) {
    return value;
  }

  return new Promise(function(resolve) {
    resolve(value);
  });
};

Promise.reject = function(value) {
  return new Promise(function(resolve, reject) {
    reject(value);
  });
};

Promise.race = function(arr) {
  return new Promise(function(resolve, reject) {
    if (!Array.isArray(arr)) {
      return reject(new TypeError("Promise.race accepts an array"));
    }

    for (var i = 0, len = arr.length; i < len; i++) {
      Promise.resolve(arr[i]).then(resolve, reject);
    }
  });
};

// Use polyfill for setImmediate for performance gains
Promise._immediateFn = setImmediate;

Promise._unhandledRejectionFn = function _unhandledRejectionFn(err, promise) {
  if (
    typeof process !== "undefined" &&
    process.listenerCount &&
    (process.listenerCount("unhandledRejection") ||
      process.listenerCount("uncaughtException"))
  ) {
    process.emit("unhandledRejection", err, promise);
    process.emit("uncaughtException", err, "unhandledRejection");
  } else if (typeof console !== "undefined" && console) {
    console.warn("Possible Unhandled Promise Rejection:", err);
  }
};

Promise._multipleResolvesFn = function _multipleResolvesFn(
  type,
  promise,
  value
) {
  if (typeof process !== "undefined" && process.emit) {
    process.emit("multipleResolves", type, promise, value);
  }
};

module.exports = Promise;


/***/ },

/***/ "./src/common.js"
/*!***********************!*\
  !*** ./src/common.js ***!
  \***********************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   chartUpdatable: () => (/* binding */ chartUpdatable),
/* harmony export */   checkSubscribtion: () => (/* binding */ checkSubscribtion),
/* harmony export */   collectStats: () => (/* binding */ collectStats),
/* harmony export */   colorIndex: () => (/* binding */ colorIndex),
/* harmony export */   convertToTemplate: () => (/* binding */ convertToTemplate),
/* harmony export */   createAreaChart: () => (/* binding */ createAreaChart),
/* harmony export */   createAxes: () => (/* binding */ createAxes),
/* harmony export */   createCandlestickChart: () => (/* binding */ createCandlestickChart),
/* harmony export */   createChart: () => (/* binding */ createChart),
/* harmony export */   createDonutChart: () => (/* binding */ createDonutChart),
/* harmony export */   createDots: () => (/* binding */ createDots),
/* harmony export */   createGroupBarChart: () => (/* binding */ createGroupBarChart),
/* harmony export */   createGroupHorizontalBarChart: () => (/* binding */ createGroupHorizontalBarChart),
/* harmony export */   createHorizontalBarChart: () => (/* binding */ createHorizontalBarChart),
/* harmony export */   createLineChart: () => (/* binding */ createLineChart),
/* harmony export */   createOval: () => (/* binding */ createOval),
/* harmony export */   createPieChart: () => (/* binding */ createPieChart),
/* harmony export */   createProgressChart: () => (/* binding */ createProgressChart),
/* harmony export */   createRandomData: () => (/* binding */ createRandomData),
/* harmony export */   createScatterPlot: () => (/* binding */ createScatterPlot),
/* harmony export */   createSparkline: () => (/* binding */ createSparkline),
/* harmony export */   createStackedAreaChart: () => (/* binding */ createStackedAreaChart),
/* harmony export */   createVerticalBarChart: () => (/* binding */ createVerticalBarChart),
/* harmony export */   curveToPoint: () => (/* binding */ curveToPoint),
/* harmony export */   defaultConf: () => (/* binding */ defaultConf),
/* harmony export */   getCanvas: () => (/* binding */ getCanvas),
/* harmony export */   lineToPoint: () => (/* binding */ lineToPoint),
/* harmony export */   migrateCandleColors: () => (/* binding */ migrateCandleColors),
/* harmony export */   moveToPoint: () => (/* binding */ moveToPoint),
/* harmony export */   path: () => (/* binding */ path),
/* harmony export */   polarToCartesian: () => (/* binding */ polarToCartesian),
/* harmony export */   processData: () => (/* binding */ processData),
/* harmony export */   processJSON: () => (/* binding */ processJSON),
/* harmony export */   xAxisDistrGrid: () => (/* binding */ xAxisDistrGrid),
/* harmony export */   xAxisDistrLabels: () => (/* binding */ xAxisDistrLabels),
/* harmony export */   xAxisGrid: () => (/* binding */ xAxisGrid),
/* harmony export */   xAxisLabels: () => (/* binding */ xAxisLabels),
/* harmony export */   yAxisGrid: () => (/* binding */ yAxisGrid),
/* harmony export */   yAxisLabels: () => (/* binding */ yAxisLabels)
/* harmony export */ });
/* harmony import */ var _babel_runtime_helpers_typeof__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/typeof */ "./node_modules/@babel/runtime/helpers/esm/typeof.js");
/* harmony import */ var _babel_runtime_helpers_toConsumableArray__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime/helpers/toConsumableArray */ "./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js");
/* harmony import */ var _nicenum__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./nicenum */ "./src/nicenum.js");




// return the status of subscription
// 本改造版为全功能免费版（仅个人自用），已移除付费校验
function checkSubscribtion(email) {
  var Settings = __webpack_require__(/*! sketch/settings */ "sketch/settings");
  Settings.setGlobalSettingForKey('user_status', true);
}

// collect stats（已移除：不再向第三方上报任何数据）
function collectStats(userId, email, appVersion, option, meta) {
  return;
}

// Generated default configuration from Resources/xchart-default-template.js.
// Keep this bundle copy in sync through the build step; migrations remain below.
function defaultConf() {
  var Settings = __webpack_require__(/*! sketch/settings */ "sketch/settings");
  var template = [{
    "name": "Default template",
    "id": 0,
    "templateVersion": 3,
    "colors": {
      "common": ["#0a84ff", "#30b0c7", "#ff9f0a", "#ff375f", "#5e5ce6", "#34c759"],
      "progressChart": ["#0a84ff"],
      "sparkline": ["#0a84ff"],
      "scatterPlot": ["#0a84ff", "#30b0c7", "#ff9f0a", "#ff375f", "#5e5ce6", "#34c759"],
      "candlestickChart": ["#da1e28", "#198038"]
    },
    "grid": {
      "type": 1,
      "lineWidth": 1,
      "color": "#e0e0e0",
      "yAxisSegments": 0
    },
    "labels": {
      "type": 1,
      "fontName": "IBM Plex Sans",
      "fontSize": 12,
      "color": "#525252",
      "yAxisPosition": "left",
      "xAxisPosition": "bottom",
      "xAxis": {
        "line": true,
        "ticks": true,
        "fontSize": 12,
        "color": "#525252"
      },
      "yAxis": {
        "line": true,
        "ticks": true,
        "fontSize": 12,
        "color": "#525252"
      }
    },
    "beginAtZero": 0,
    "lineType": 0,
    "spiderLabels": false,
    "histogram": { "binMode": "auto", "binCount": 8, "binWidth": 0 },
    "combo": { "axisAssignment": "auto", "margin": 0.24, "innerGap": 0.12, "roundTop": 0 },
    "sorting": 0,
    "typeOfCircle": 0,
    "segmentGap": 0,
    "interaction": {
      "showValueTooltip": true
    },
    "lineChart": {
      "lineWidth": 1.5,
      "dotType": 1,
      "dotDiameter": 5
    },
    "areaChart": {
      "lineWidth": 2,
      "opacity": 0.22,
      "type": "normal",
      "fillStyle": "gradient-line"
    },
    "verticalBarChart": {
      "margin": 0.24,
      "stackGap": 1,
      "roundTop": 0,
      "useOneColor": false
    },
    "percentStackedVerticalBarChart": {
      "margin": 0.24,
      "stackGap": 1,
      "roundTop": 0
    },
    "horizontalBarChart": {
      "margin": 0.24,
      "stackGap": 1,
      "roundTop": 0,
      "useOneColor": false
    },
    "percentStackedHorizontalBarChart": {
      "margin": 0.24,
      "stackGap": 1,
      "roundTop": 0
    },
    "groupedBarChart": {
      "margin": 0.2,
      "innerGap": 0.12,
      "roundTop": 0
    },
    "groupedHorizontalBarChart": {
      "margin": 0.2,
      "innerGap": 0.12,
      "roundTop": 0
    },
    "donutChart": {
      "thicknessOfDonut": 28
    },
    "progressChart": {
      "backgroundColor": "#e0e0e0",
      "thicknessOfProgress": 12,
      "endOfLine": 1
    },
    "sparkline": {
      "lineWidth": 1.5,
      "dotDiameter": 4
    },
    "scatterPlot": {
      "dotDiameter": 7
    },
    "candlestickChart": {
      "margin": 0.2,
      "unfilledNegativeBoxes": false
    }
  }];
  Settings.setGlobalSettingForKey('xchart.templates', JSON.stringify(template));
}

// Migrate built-in defaults and the legacy candlestick color order.
// User-created templates keep their settings.
function migrateCandleColors() {
  var Settings = __webpack_require__(/*! sketch/settings */ "sketch/settings");
  var raw = Settings.globalSettingForKey('xchart.templates');
  if (raw == undefined || raw == null) return;
  try {
    var templates = JSON.parse(raw);
    if (!Array.isArray(templates)) return;
    var changed = false;
    var previousDefaultPalette = ['#0f62fe', '#24a148', '#ff832b', '#da1e28', '#8a3ffc', '#007d79'];
    var defaultPalette = ['#0a84ff', '#30b0c7', '#ff9f0a', '#ff375f', '#5e5ce6', '#34c759'];
    templates.forEach(function (t) {
      var c = t.colors && t.colors.candlestickChart;
      var common = t.colors && t.colors.common;
      if (Number(t.id) === 0 && t.colors && (!Array.isArray(t.colors.scatterPlot) || t.colors.scatterPlot.length < defaultPalette.length)) {
        t.colors.scatterPlot = defaultPalette.slice();
        changed = true;
      }
      if (Number(t.id) === 0 && Array.isArray(common) && common.length === previousDefaultPalette.length && common.every(function (color, index) {
        return String(color).toLowerCase() === previousDefaultPalette[index];
      })) {
        t.colors.common = defaultPalette.slice();
        if (Array.isArray(t.colors.progressChart) && String(t.colors.progressChart[0]).toLowerCase() === '#0f62fe') t.colors.progressChart = ['#0a84ff'];
        if (Array.isArray(t.colors.sparkline) && String(t.colors.sparkline[0]).toLowerCase() === '#0f62fe') t.colors.sparkline = ['#0a84ff'];
        if (Array.isArray(t.colors.scatterPlot) && String(t.colors.scatterPlot[0]).toLowerCase() === '#0f62fe') t.colors.scatterPlot = defaultPalette.slice();
        changed = true;
      }
      if (Array.isArray(c) && c.length === 2 && c[0] === '#198038' && c[1] === '#da1e28') {
        t.colors.candlestickChart = ['#da1e28', '#198038'];
        changed = true;
      }
      // Upgrade the persisted built-in template as a whole. User-created templates
      // keep their settings; only template id 0 and legacy/default-shaped values change.
      if (Number(t.id) === 0 && t.colors && Array.isArray(t.colors.common)) {
        var looksLegacy = Number(t.templateVersion || 0) < 2 || t.colors.common.some(function (color) { return ['#6929c4', '#1192e8', '#005d5d'].indexOf(String(color).toLowerCase()) >= 0; }) ||
          (t.lineChart && Number(t.lineChart.lineWidth) === 2) || (t.areaChart && (t.areaChart.fillStyle === 'solid' || Number(t.areaChart.opacity) >= 0.4)) ||
          (t.verticalBarChart && Number(t.verticalBarChart.margin) === 0.4) || (t.labels && t.labels.color === '#6f6f6f');
        if (looksLegacy) {
          t.colors.common = defaultPalette.slice();
          t.colors.progressChart = ['#0a84ff']; t.colors.sparkline = ['#0a84ff']; t.colors.scatterPlot = defaultPalette.slice(); t.colors.candlestickChart = ['#da1e28', '#198038'];
          t.grid = { type: 1, lineWidth: 1, color: '#e0e0e0', yAxisSegments: 0 };
          t.labels = { type: 1, fontName: 'IBM Plex Sans', fontSize: 12, color: '#525252', yAxisPosition: 'left', xAxisPosition: 'bottom', xAxis: { line: true, ticks: true, fontSize: 12, color: '#525252' }, yAxis: { line: true, ticks: true, fontSize: 12, color: '#525252' } };
          t.lineChart = { lineWidth: 1.5, dotType: 1, dotDiameter: 5 };
          t.areaChart = { lineWidth: 2, opacity: 0.22, fillStyle: 'gradient-line' };
          t.verticalBarChart = { margin: 0.24, stackGap: 1, roundTop: 0, useOneColor: false };
          t.horizontalBarChart = { margin: 0.24, stackGap: 1, roundTop: 0, useOneColor: false };
          t.percentStackedVerticalBarChart = { margin: 0.24, stackGap: 1, roundTop: 0 }; t.percentStackedHorizontalBarChart = { margin: 0.24, stackGap: 1, roundTop: 0 };
          t.groupedBarChart = { margin: 0.2, innerGap: 0.12, roundTop: 0 }; t.groupedHorizontalBarChart = { margin: 0.2, innerGap: 0.12, roundTop: 0 };
          t.combo = { axisAssignment: 'auto', margin: 0.24, innerGap: 0.12, roundTop: 0 };
          t.donutChart = { thicknessOfDonut: 28 }; t.progressChart = { backgroundColor: '#e0e0e0', thicknessOfProgress: 12, endOfLine: 1 }; t.sparkline = { lineWidth: 1.5, dotDiameter: 4 }; t.scatterPlot = { dotDiameter: 7 }; t.candlestickChart = { margin: 0.2, unfilledNegativeBoxes: false };
          t.templateVersion = 3; changed = true;
        }
        if (Number(t.templateVersion || 0) < 3) {
          ['verticalBarChart', 'horizontalBarChart', 'percentStackedVerticalBarChart', 'percentStackedHorizontalBarChart', 'groupedBarChart', 'groupedHorizontalBarChart', 'combo'].forEach(function (key) {
            if (t[key] && Number(t[key].roundTop) === 4) t[key].roundTop = 0;
          });
          t.templateVersion = 3;
          changed = true;
        }
      }
    });
    // 迁移早期工作区生成的 8 色默认模板，统一到当前 6 色默认色板。
    var oldDefaultPalette = ['#2563eb', '#14b8a6', '#f59f0b', '#f43f5e', '#8b5cf6', '#22c55e', '#06b6d4', '#64748b'];
    var currentDefaultPalette = defaultPalette;
    templates.forEach(function (t) {
      var common = t && t.colors && t.colors.common;
      if (t && Number(t.id) === 0 && Array.isArray(common) && common.length === oldDefaultPalette.length && common.every(function (color, index) { return String(color).toLowerCase() === oldDefaultPalette[index]; })) {
        t.colors.common = currentDefaultPalette.slice();
        changed = true;
      }
    });
    if (changed) Settings.setGlobalSettingForKey('xchart.templates', JSON.stringify(templates));
  } catch (e) {}
}
function convertToTemplate() {
  var Settings = __webpack_require__(/*! sketch/settings */ "sketch/settings");
  var oldConf = JSON.parse(Settings.globalSettingForKey('conf'));
  var template = [{
    "name": "Default template",
    "id": 0,
    "colors": {
      "common": oldConf.lineChart.colors,
      "progressChart": oldConf.progressChart.colors,
      "sparkline": oldConf.sparkline.colors,
      "scatterPlot": oldConf.scatterPlot.colors,
      "candlestickChart": oldConf.candlestickChart.colors
    },
    "grid": {
      "type": Number(oldConf.lineChart.grid),
      "lineWidth": 1,
      "color": "#e0e0e0",
      "yAxisSegments": 0
    },
    "labels": {
      "type": Number(oldConf.lineChart.labels),
      "fontName": "IBM Plex Sans",
      "fontSize": 10,
      "color": "#6f6f6f",
      "yAxisPosition": "left",
      "xAxisPosition": "bottom",
      "xAxis": {
        "line": true,
        "ticks": true,
        "fontSize": 10,
        "color": "#6f6f6f"
      },
      "yAxis": {
        "line": true,
        "ticks": true,
        "fontSize": 10,
        "color": "#6f6f6f"
      }
    },
    "beginAtZero": 0,
    "lineType": Number(oldConf.lineChart.typeOfLine),
    "sorting": Number(oldConf.pieChart.sort),
    "typeOfCircle": Number(oldConf.pieChart.type),
    "lineChart": {
      "lineWidth": Number(oldConf.lineChart.thickness),
      "dotType": Number(oldConf.lineChart.dots),
      "dotDiameter": Number(oldConf.lineChart.diameter)
    },
    "areaChart": {
      "lineWidth": 0,
      "opacity": 0.8
    },
    "verticalBarChart": {
      "margin": Number(oldConf.verticalBarChart.barWidth),
      "roundTop": 0,
      "useOneColor": true
    },
    "horizontalBarChart": {
      "margin": Number(oldConf.horizontalBarChart.barWidth),
      "roundTop": 0,
      "useOneColor": true
    },
    "groupedBarChart": {
      "margin": 0.4,
      "roundTop": 0
    },
    "groupedHorizontalBarChart": {
      "margin": 0.4,
      "roundTop": 0
    },
    "donutChart": {
      "thicknessOfDonut": Number(oldConf.donutChart.thickness)
    },
    "progressChart": {
      "backgroundColor": "#e0e0e0",
      "thicknessOfProgress": Number(oldConf.progressChart.thickness),
      "endOfLine": Number(oldConf.progressChart.end)
    },
    "sparkline": {
      "lineWidth": Number(oldConf.sparkline.thickness),
      "dotDiameter": Number(oldConf.sparkline.diameter)
    },
    "scatterPlot": {
      "dotDiameter": Number(oldConf.scatterPlot.diameter)
    },
    "candlestickChart": {
      "margin": Number(oldConf.candlestickChart.margin),
      "unfilledNegativeBoxes": false
    }
  }];
  Settings.setGlobalSettingForKey('xchart.templates', JSON.stringify(template));
}

// function that returns all parameters of canvases
function getCanvas(context) {
  var sketch = __webpack_require__(/*! sketch */ "sketch"),
    UI = __webpack_require__(/*! sketch/ui */ "sketch/ui"),
    Settings = __webpack_require__(/*! sketch/settings */ "sketch/settings"),
    doc = sketch.getSelectedDocument();
  var selection = doc.selectedLayers,
    canvasArr = new Array(),
    error = false,
    canvas;
  function isNumeric(n) {
    return !isNaN(parseFloat(n)) && isFinite(n);
  }
  if (selection.length > 0) {
    selection.forEach(function (layer) {
      if (layer.shapeType === "Rectangle" || layer.shapeType === "Oval") {
        layer.style.fills = [];
        layer.style.borders = [];
      }
      var startNum = isNumeric(layer.name) ? parseFloat(layer.name) : "false";
      var setting = Settings.layerSettingForKey(layer, 'localConf');
      canvas = {
        layer: layer.id,
        height: layer.frame.height,
        width: layer.frame.width,
        x: layer.frame.x,
        y: layer.frame.y,
        layerType: layer.shapeType,
        startNum: startNum,
        parent: layer.parent.id,
        conf: setting
      };
      canvasArr.push(canvas);
    });
  }
  return [canvasArr, error];
}
function chartUpdatable(context) {
  var sketch = __webpack_require__(/*! sketch */ "sketch"),
    UI = __webpack_require__(/*! sketch/ui */ "sketch/ui"),
    Settings = __webpack_require__(/*! sketch/settings */ "sketch/settings"),
    doc = sketch.getSelectedDocument();
  var selection = doc.selectedLayers,
    updatable = false;
  if (selection.length > 0) {
    selection.forEach(function (layer) {
      var layerConf = Settings.layerSettingForKey(layer, 'localConf');
      if (layerConf != undefined) {
        if (layerConf.data.selected == "random") {
          updatable = true;
        } else if (layerConf.data.selected == "table" && layerConf.data.csv.gsLink != null) {
          updatable = true;
        } else if (layerConf.data.selected == "json" && layerConf.data.json.jsonLink != null) {
          updatable = true;
        }
      }
    });
  } else {
    UI.message('请至少选择一个图层或图表');
  }
  return updatable;
}

// Helper SVG functions






// LABELS
// X/Y 轴独立样式读取（向后兼容旧字段：无 xAxis/yAxis 子对象时回退顶层 fontSize/color）





// Y 轴刻度段数计算（grid.yAxisSegments 控制段数，0=自动 30px 间隔）



// GRIDS



// AXES (轴线 + tick 短线)

// colorPalette index

// Create random data set
function createRandomData(rows, columns, min, max, distr, type) {
  var dataRow = new Array(),
    dataTable = new Array(),
    dataMax = new Array(),
    dataMin = new Array(),
    headers = [];
  function randNum(min, max, col) {
    min = Number(min);
    max = Number(max);
    col = Number(col);
    var data = new Array();
    for (var i = 0; i < col; i++) {
      data[i] = Number(Math.random() * (max - min) + min).toFixed(0);
    }
    return data;
  }
  function trendUp(min, max, col) {
    min = Number(min);
    max = Number(max);
    col = Number(col);
    var step = (max - min) / col,
      data = new Array();
    for (var i = 0; i < col; i++) {
      var tempNum = min + step * (Math.random() * (1.3 - 0.5) + 0.5);
      min += tempNum - min;
      data[i] = tempNum.toFixed(0);
    }
    return data;
  }
  function trendDown(min, max, col) {
    min = Number(min);
    max = Number(max);
    col = Number(col);
    var step = (max - min) / col,
      data = new Array();
    for (var i = 0; i < col; i++) {
      var tempNum = max - step * (Math.random() * (1.3 - 0.5) + 0.5);
      max -= max - tempNum;
      data[i] = tempNum.toFixed(0);
    }
    return data;
  }
  function normalDistr(min, max, col) {
    max = Number(max);
    min = Number(min);
    col = Number(col - 1);
    var data = new Array(),
      originalMax = max;
    for (var i = 0; i <= col; i++) {
      max = max * Math.random();
      var c = min,
        b = 4 * (max - min) / col,
        a = -b / col;
      var tempNum = a * Math.pow(i, 2) + b * i + c;
      data[i] = tempNum.toFixed(0);
      max = originalMax;
    }
    return data;
  }
  var funcArr = [randNum, trendUp, trendDown, normalDistr];
  if (type == "candlestickChart") {
    var newRandom = function newRandom(min, max) {
      return Math.random() * (max - min) + min;
    };
    var range = max - min,
      minTrend = min + newRandom(range * 0.1, range * 0.3),
      maxTrend = max - newRandom(range * 0.1, range * 0.3),
      trendStep = (maxTrend - minTrend) / columns,
      startUp = minTrend,
      startDown = maxTrend,
      centerPoint,
      high,
      close,
      open,
      low,
      delta,
      highArr = new Array(),
      closeArr = new Array(),
      openArr = new Array(),
      lowArr = new Array();
    for (var j = 0; j < columns; j++) {
      if (distr == "1") {
        // Up
        centerPoint = Number(startUp) + trendStep * newRandom(0.7, 1.3);
        startUp = centerPoint;
      } else if (distr == "2") {
        // Down
        centerPoint = Number(startDown) - trendStep * newRandom(0.7, 1.3);
        startDown = centerPoint;
      } else {
        // Noise
        centerPoint = newRandom(range * 0.1, range * 0.9);
      }
      high = centerPoint * newRandom(1.1, 1.3);
      low = centerPoint * newRandom(0.7, 0.9);
      delta = high - low;
      close = newRandom(Number(low) + 0.2 * delta, Number(high) - 0.2 * delta);
      if (close < high - (high - low) / 2) {
        var openDelta = high - close;
        open = newRandom(Number(close) + 0.2 * openDelta, Number(high) - 0.2 * openDelta);
      } else {
        var openDelta = close - low;
        open = newRandom(Number(low) + 0.2 * openDelta, Number(close) - 0.2 * openDelta);
      }
      highArr[j] = high.toFixed(0);
      closeArr[j] = close.toFixed(0);
      openArr[j] = open.toFixed(0);
      lowArr[j] = low.toFixed(0);
    }
    dataTable[0] = highArr;
    dataTable[1] = closeArr;
    dataTable[2] = openArr;
    dataTable[3] = lowArr;
  } else {
    for (var i = 0; i < rows; i++) {
      if (distr == "0") {
        dataRow = randNum(min, max, columns);
      } else if (distr == "1") {
        dataRow = trendUp(min, max, columns);
      } else if (distr == "2") {
        if (type == "scatterPlot" && i == 0) {
          dataRow = trendUp(min, max, columns);
        } else {
          dataRow = trendDown(min, max, columns);
        }
      } else if (distr == "3") {
        if (type == "scatterPlot" && i == 0) {
          dataRow = trendUp(min, max, columns);
        } else {
          dataRow = normalDistr(min, max, columns);
        }
      } else {
        var _randNum = Number(Math.random() * (funcArr.length - 1)).toFixed(0);
        dataRow = funcArr[_randNum](min, max, columns);
      }
      dataTable[i] = dataRow;
      dataMax[i] = Math.max.apply(Math, (0,_babel_runtime_helpers_toConsumableArray__WEBPACK_IMPORTED_MODULE_1__["default"])(dataRow));
      dataMin[i] = Math.min.apply(Math, (0,_babel_runtime_helpers_toConsumableArray__WEBPACK_IMPORTED_MODULE_1__["default"])(dataRow));
    }
  }
  for (var h = 0; h < columns; h++) {
    headers[h] = "Text";
  }
  var dataObj = {
    table: dataTable,
    max: Math.max.apply(Math, dataMax),
    min: Math.min.apply(Math, dataMin),
    rows: dataTable.length,
    columns: dataTable[0].length,
    header: headers
  };
  return dataObj;
}

function parseDataNumber(value) {
  if (value === null || value === undefined) throw new Error('数据中存在空值');
  var original = String(value).trim();
  if (!original) throw new Error('数据中存在空值');
  var text = /%$/.test(original) ? original.slice(0, -1).trim() : original;
  text = text.replace(/^[\$\u00a5\uffe5\u20ac\u00a3]\s*/, '');
  if (/^[+-]?\d{1,3}(,\d{3})+(\.\d+)?(?:[eE][+-]?\d+)?$/.test(text)) text = text.replace(/,/g, '');
  if (!/^[+-]?(?:\d+\.?\d*|\.\d+)(?:[eE][+-]?\d+)?$/.test(text)) throw new Error('无效数字：' + original);
  var number = Number(text);
  if (!isFinite(number)) throw new Error('数字超出可用范围：' + original);
  return number;
}

// Create data set from real data
function processData(csv) {
  function transpose(a) {
    return Object.keys(a[0]).map(function (c) {
      return a.map(function (r) {
        return r[c];
      });
    });
  }
  function isNumeric(n) {
    return !isNaN(parseFloat(n)) && isFinite(n);
  }
  function tableMin(N) {
    var min = new Array();
    for (var i in N) {
      min[i] = Math.min.apply(Math, (0,_babel_runtime_helpers_toConsumableArray__WEBPACK_IMPORTED_MODULE_1__["default"])(N[i]));
    }
    return Math.min.apply(Math, min);
  }
  function tableMax(N) {
    var max = new Array();
    for (var i in N) {
      max[i] = Math.max.apply(Math, (0,_babel_runtime_helpers_toConsumableArray__WEBPACK_IMPORTED_MODULE_1__["default"])(N[i]));
    }
    return Math.max.apply(Math, max);
  }
  var dataObj;
  if (csv.type === null) {
    var col = csv.data[0].length,
      row = csv.data.length,
      newData = csv.data.map(function (dataRow) {
        return dataRow.slice();
      }),
      header;
    if (csv.headers == true) {
      header = newData[0];
      newData.splice(0, 1);
      for (var i = 0; i < row - 1; i++) {
        for (var j = 0; j < col; j++) {
          newData[i][j] = parseDataNumber(newData[i][j]);
        }
      }
      row = row - 1;
    } else {
      header = false;
      for (var _i5 = 0; _i5 < row; _i5++) {
        for (var _j2 = 0; _j2 < col; _j2++) {
          newData[_i5][_j2] = parseDataNumber(newData[_i5][_j2]);
        }
      }
    }
    dataObj = {
      table: newData,
      rows: row,
      columns: col,
      min: tableMin(newData),
      max: tableMax(newData),
      header: header
    };
  } else {
    var _newData = new Array(),
      selectedRows = new Array(),
      headerIndex,
      transposedTable = transpose(csv.data);
    csv.columns.forEach(function (column) {
      if (column.checked) {
        selectedRows.push(column.index);
      }
    });
    selectedRows.forEach(function (row) {
      _newData.push(transposedTable[row]);
    });
    for (var _i6 = 0; _i6 < _newData.length; _i6++) {
      for (var _j3 = 0; _j3 < _newData[0].length; _j3++) {
        _newData[_i6][_j3] = parseDataNumber(_newData[_i6][_j3]);
      }
    }
    csv.header.forEach(function (header) {
      if (header.checked) {
        headerIndex = header.index;
      }
    });
    dataObj = {
      table: _newData,
      rows: _newData.length,
      columns: _newData[0].length,
      min: tableMin(_newData),
      max: tableMax(_newData),
      header: transposedTable[headerIndex]
    };
  }
  log(dataObj);
  return dataObj;
}

// Create data set from JSON
function processJSON(JSON, rawKeys, rawHeader) {
  var keys = new Array(),
    headerKey = "",
    dataTable = new Array(),
    dataMax = new Array(),
    dataMin = new Array();
  function getValues(obj, key) {
    var objects = [];
    for (var i in obj) {
      if (!obj.hasOwnProperty(i)) continue;
      if ((0,_babel_runtime_helpers_typeof__WEBPACK_IMPORTED_MODULE_0__["default"])(obj[i]) == 'object') {
        objects = objects.concat(getValues(obj[i], key));
      } else if (i == key) {
        objects.push(obj[i]);
      }
    }
    return objects;
  }
  rawKeys.forEach(function (key) {
    if (key.checked == true) {
      keys.push(key.name);
    }
  });
  rawHeader.forEach(function (header) {
    if (header.checked == true) {
      headerKey = header.name;
    }
  });
  var headers = getValues(JSON, headerKey);
  for (var i in keys) {
    var row = getValues(JSON, keys[i]);
    for (var j in row) {
      row[j] = parseDataNumber(row[j]);
    }
    dataTable[i] = row;
    dataMax[i] = Math.max.apply(Math, (0,_babel_runtime_helpers_toConsumableArray__WEBPACK_IMPORTED_MODULE_1__["default"])(dataTable[i]));
    dataMin[i] = Math.min.apply(Math, (0,_babel_runtime_helpers_toConsumableArray__WEBPACK_IMPORTED_MODULE_1__["default"])(dataTable[i]));
  }
  var dataObj = {
    table: dataTable,
    max: Math.max.apply(Math, dataMax),
    min: Math.min.apply(Math, dataMin),
    rows: dataTable.length,
    columns: dataTable[0].length,
    header: headers
  };
  return dataObj;
}

// Line chart






// Area chart





// Stacked area chart













function loadXChartSharedModule(fileName, exportName) {
  var bundle = context.command && context.command.pluginBundle ? context.command.pluginBundle() : context.plugin;
  var resource = bundle && bundle.urlForResourceNamed ? bundle.urlForResourceNamed(fileName) : null;
  if (!resource) throw new Error('Missing shared chart resource: ' + fileName);
  var source = String(NSString.stringWithContentsOfFile_encoding_error(resource.path(), NSUTF8StringEncoding, null));
  return eval(source + '\n;' + exportName + ';');
}
function createChart(canvas, configuration) {
  var sharedCore = loadXChartSharedModule('xchart-core.js', 'XChartCore');
  var sharedData = loadXChartSharedModule('xchart-data.js', 'XChartData');
  var sharedAdapter = loadXChartSharedModule('xchart-sketch-adapter.js', 'XChartSketchAdapter');
  var sharedSketch = __webpack_require__(/*! sketch */ "sketch");
  return sharedAdapter.renderCharts({
    core: sharedCore,
    sketch: sharedSketch,
    Settings: __webpack_require__(/*! sketch/settings */ "sketch/settings"),
    document: sharedSketch.getSelectedDocument(),
    canvases: canvas,
    configuration: configuration,
    data: sharedData,
    processors: { createRandomData: createRandomData, processData: processData, processJSON: processJSON }
  });
}

/***/ },

/***/ "./src/nicenum.js"
/*!************************!*\
  !*** ./src/nicenum.js ***!
  \************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   calculateNiceNum: () => (/* binding */ calculateNiceNum)
/* harmony export */ });
function calculateNiceNum(minNum, maxNum, height) {
  // Nice max and min functions
  var minPoint,
    maxPoint,
    maxTicks = 10,
    minStep = 30,
    range,
    tickSpacing,
    niceMin,
    niceMax;
  /**
   * Instantiates a new instance of the NiceScale class.
   *
   *  min the minimum data point on the axis
   *  max the maximum data point on the axis
   */
  function niceScale(min, max) {
    minPoint = Number(min);
    maxPoint = Number(max);
    if (!isFinite(minPoint) || !isFinite(maxPoint)) {
      minPoint = 0;
      maxPoint = 1;
    } else if (minPoint === maxPoint) {
      minPoint -= 1;
      maxPoint += 1;
    }
    calculate();
    if (height != false) {
      var _range = niceMax - niceMin,
        maxNumTicks = Math.max(2, Math.floor(height / minStep)),
        dividers = [0.1, 0.2, 0.5];
      var step = dividers[0],
        numLines = Math.ceil(_range / step),
        i = 0,
        count = 1;
      while (numLines >= maxNumTicks) {
        step = dividers[i] * count;
        numLines = Math.ceil(_range / step);
        if (i === 2) {
          i = 0;
          count = count * 10;
        } else {
          i++;
        }
      }
      niceMax = niceMin + step * numLines;
    }
    return {
      niceMinimum: niceMin,
      niceMaximum: niceMax
    };
  }

  /**
   * Calculate and update values for tick spacing and nice
   * minimum and maximum data points on the axis.
   */
  function calculate() {
    range = niceNum(maxPoint - minPoint, false);
    tickSpacing = niceNum(range / (maxTicks - 1), true);
    niceMin = Math.floor(minPoint / tickSpacing) * tickSpacing;
    niceMax = Math.ceil(maxPoint / tickSpacing) * tickSpacing;
  }

  /**
   * Returns a "nice" number approximately equal to range Rounds
   * the number if round = true Takes the ceiling if round = false.
   *
   *  localRange the data range
   *  round whether to round the result
   *  a "nice" number to be used for the data range
   */
  function niceNum(localRange, round) {
    var exponent; /** exponent of localRange */
    var fraction; /** fractional part of localRange */
    var niceFraction; /** nice, rounded fraction */

    exponent = Math.floor(Math.log10(localRange));
    fraction = localRange / Math.pow(10, exponent);
    if (round) {
      if (fraction < 1.5) niceFraction = 1;else if (fraction < 3) niceFraction = 2;else if (fraction < 7) niceFraction = 5;else niceFraction = 10;
    } else {
      if (fraction <= 1) niceFraction = 1;else if (fraction <= 2) niceFraction = 2;else if (fraction <= 5) niceFraction = 5;else niceFraction = 10;
    }
    return niceFraction * Math.pow(10, exponent);
  }
  return niceScale(minNum, maxNum);
}

/***/ },

/***/ "./node_modules/mocha-js-delegate/index.js"
/*!*************************************************!*\
  !*** ./node_modules/mocha-js-delegate/index.js ***!
  \*************************************************/
(module) {

/* globals MOClassDescription, NSObject, NSSelectorFromString, NSClassFromString, MOPropertyDescription */

module.exports = function MochaDelegate(definition, superclass) {
  var uniqueClassName =
    'MochaJSDelegate_DynamicClass_' + NSUUID.UUID().UUIDString()

  var delegateClassDesc = MOClassDescription.allocateDescriptionForClassWithName_superclass_(
    uniqueClassName,
    superclass || NSObject
  )

  // Storage
  var handlers = {}
  var ivars = {}

  // Define an instance method
  function setHandlerForSelector(selectorString, func) {
    var handlerHasBeenSet = selectorString in handlers
    var selector = NSSelectorFromString(selectorString)

    handlers[selectorString] = func

    /*
      For some reason, Mocha acts weird about arguments: https://github.com/logancollins/Mocha/issues/28
      We have to basically create a dynamic handler with a likewise dynamic number of predefined arguments.
    */
    if (!handlerHasBeenSet) {
      var args = []
      var regex = /:/g
      while (regex.exec(selectorString)) {
        args.push('arg' + args.length)
      }

      // eslint-disable-next-line no-eval
      var dynamicFunction = eval(
        '(function (' +
          args.join(', ') +
          ') { return handlers[selectorString].apply(this, arguments); })'
      )

      delegateClassDesc.addInstanceMethodWithSelector_function(
        selector,
        dynamicFunction
      )
    }
  }

  // define a property
  function setIvar(key, value) {
    var ivarHasBeenSet = key in handlers

    ivars[key] = value

    if (!ivarHasBeenSet) {
      delegateClassDesc.addInstanceVariableWithName_typeEncoding(key, '@')
      var description = MOPropertyDescription.new()
      description.name = key
      description.typeEncoding = '@'
      description.weak = true
      description.ivarName = key
      delegateClassDesc.addProperty(description)
    }
  }

  this.getClass = function() {
    return NSClassFromString(uniqueClassName)
  }

  this.getClassInstance = function(instanceVariables) {
    var instance = NSClassFromString(uniqueClassName).new()
    Object.keys(ivars).forEach(function(key) {
      instance[key] = ivars[key]
    })
    Object.keys(instanceVariables || {}).forEach(function(key) {
      instance[key] = instanceVariables[key]
    })
    return instance
  }
  // alias
  this.new = this.getClassInstance

  // Convenience
  if (typeof definition === 'object') {
    Object.keys(definition).forEach(
      function(key) {
        if (typeof definition[key] === 'function') {
          setHandlerForSelector(key, definition[key])
        } else {
          setIvar(key, definition[key])
        }
      }
    )
  }

  delegateClassDesc.registerClass()
}


/***/ },

/***/ "./node_modules/sketch-module-web-view/lib/browser-api.js"
/*!****************************************************************!*\
  !*** ./node_modules/sketch-module-web-view/lib/browser-api.js ***!
  \****************************************************************/
(module) {

function parseHexColor(color) {
  // Check the string for incorrect formatting.
  if (!color || color[0] !== '#') {
    if (
      color &&
      typeof color.isKindOfClass === 'function' &&
      color.isKindOfClass(NSColor)
    ) {
      return color
    }
    throw new Error(
      'Incorrect color formating. It should be an hex color: #RRGGBBAA'
    )
  }

  // append FF if alpha channel is not specified.
  var source = color.substr(1)
  if (source.length === 3) {
    source += 'F'
  } else if (source.length === 6) {
    source += 'FF'
  }
  // Convert the string from #FFF format to #FFFFFF format.
  var hex
  if (source.length === 4) {
    for (var i = 0; i < 4; i += 1) {
      hex += source[i]
      hex += source[i]
    }
  } else if (source.length === 8) {
    hex = source
  } else {
    return NSColor.whiteColor()
  }

  var r = parseInt(hex.slice(0, 2), 16) / 255
  var g = parseInt(hex.slice(2, 4), 16) / 255
  var b = parseInt(hex.slice(4, 6), 16) / 255
  var a = parseInt(hex.slice(6, 8), 16) / 255

  return NSColor.colorWithSRGBRed_green_blue_alpha(r, g, b, a)
}

module.exports = function (browserWindow, panel, webview) {
  // keep reference to the subviews
  browserWindow._panel = panel
  browserWindow._webview = webview
  browserWindow._destroyed = false

  browserWindow.destroy = function () {
    return panel.close()
  }

  browserWindow.close = function () {
    if (panel.delegate().utils && panel.delegate().utils.parentWindow) {
      var shouldClose = true
      browserWindow.emit('close', {
        get defaultPrevented() {
          return !shouldClose
        },
        preventDefault: function () {
          shouldClose = false
        },
      })
      if (shouldClose) {
        panel.delegate().utils.parentWindow.endSheet(panel)
      }
      return
    }

    if (!browserWindow.isClosable()) {
      return
    }

    panel.performClose(null)
  }

  function focus(focused) {
    if (!browserWindow.isVisible()) {
      return
    }
    if (focused) {
      NSApplication.sharedApplication().activateIgnoringOtherApps(true)
      panel.makeKeyAndOrderFront(null)
    } else {
      panel.orderBack(null)
      NSApp.mainWindow().makeKeyAndOrderFront(null)
    }
  }

  browserWindow.focus = focus.bind(this, true)
  browserWindow.blur = focus.bind(this, false)

  browserWindow.isFocused = function () {
    return panel.isKeyWindow()
  }

  browserWindow.isDestroyed = function () {
    return browserWindow._destroyed
  }

  browserWindow.show = function () {
    // This method is supposed to put focus on window, however if the app does not
    // have focus then "makeKeyAndOrderFront" will only show the window.
    NSApp.activateIgnoringOtherApps(true)

    if (panel.delegate().utils && panel.delegate().utils.parentWindow) {
      return panel.delegate().utils.parentWindow.beginSheet_completionHandler(
        panel,
        __mocha__.createBlock_function('v16@?0q8', function () {
          browserWindow.emit('closed')
        })
      )
    }

    return panel.makeKeyAndOrderFront(null)
  }

  browserWindow.showInactive = function () {
    return panel.orderFrontRegardless()
  }

  browserWindow.hide = function () {
    return panel.orderOut(null)
  }

  browserWindow.isVisible = function () {
    return panel.isVisible()
  }

  browserWindow.isModal = function () {
    return false
  }

  browserWindow.maximize = function () {
    if (!browserWindow.isMaximized()) {
      panel.zoom(null)
    }
  }
  browserWindow.unmaximize = function () {
    if (browserWindow.isMaximized()) {
      panel.zoom(null)
    }
  }

  browserWindow.isMaximized = function () {
    if ((panel.styleMask() & NSResizableWindowMask) !== 0) {
      return panel.isZoomed()
    }
    var rectScreen = NSScreen.mainScreen().visibleFrame()
    var rectWindow = panel.frame()
    return (
      rectScreen.origin.x == rectWindow.origin.x &&
      rectScreen.origin.y == rectWindow.origin.y &&
      rectScreen.size.width == rectWindow.size.width &&
      rectScreen.size.height == rectWindow.size.height
    )
  }

  browserWindow.minimize = function () {
    return panel.miniaturize(null)
  }

  browserWindow.restore = function () {
    return panel.deminiaturize(null)
  }

  browserWindow.isMinimized = function () {
    return panel.isMiniaturized()
  }

  browserWindow.setFullScreen = function (fullscreen) {
    if (fullscreen !== browserWindow.isFullscreen()) {
      panel.toggleFullScreen(null)
    }
  }

  browserWindow.isFullscreen = function () {
    return panel.styleMask() & NSFullScreenWindowMask
  }

  browserWindow.setAspectRatio = function (aspectRatio /* , extraSize */) {
    // Reset the behaviour to default if aspect_ratio is set to 0 or less.
    if (aspectRatio > 0.0) {
      panel.setAspectRatio(NSMakeSize(aspectRatio, 1.0))
    } else {
      panel.setResizeIncrements(NSMakeSize(1.0, 1.0))
    }
  }

  browserWindow.setBounds = function (bounds, animate) {
    if (!bounds) {
      return
    }

    // Do nothing if in fullscreen mode.
    if (browserWindow.isFullscreen()) {
      return
    }

    const newBounds = Object.assign(browserWindow.getBounds(), bounds)

    // TODO: Check size constraints since setFrame does not check it.
    // var size = bounds.size
    // size.SetToMax(GetMinimumSize());
    // gfx::Size max_size = GetMaximumSize();
    // if (!max_size.IsEmpty())
    //   size.SetToMin(max_size);

    var cocoaBounds = NSMakeRect(
      newBounds.x,
      0,
      newBounds.width,
      newBounds.height
    )
    // Flip Y coordinates based on the primary screen
    var screen = NSScreen.screens().firstObject()
    cocoaBounds.origin.y = NSHeight(screen.frame()) - newBounds.y

    panel.setFrame_display_animate(cocoaBounds, true, animate)
  }

  browserWindow.getBounds = function () {
    const cocoaBounds = panel.frame()
    var mainScreenRect = NSScreen.screens().firstObject().frame()
    return {
      x: cocoaBounds.origin.x,
      y: Math.round(NSHeight(mainScreenRect) - cocoaBounds.origin.y),
      width: cocoaBounds.size.width,
      height: cocoaBounds.size.height,
    }
  }

  browserWindow.setContentBounds = function (bounds, animate) {
    // TODO:
    browserWindow.setBounds(bounds, animate)
  }

  browserWindow.getContentBounds = function () {
    // TODO:
    return browserWindow.getBounds()
  }

  browserWindow.setSize = function (width, height, animate) {
    // TODO: handle resizing around center
    return browserWindow.setBounds({ width: width, height: height }, animate)
  }

  browserWindow.getSize = function () {
    var bounds = browserWindow.getBounds()
    return [bounds.width, bounds.height]
  }

  browserWindow.setContentSize = function (width, height, animate) {
    // TODO: handle resizing around center
    return browserWindow.setContentBounds(
      { width: width, height: height },
      animate
    )
  }

  browserWindow.getContentSize = function () {
    var bounds = browserWindow.getContentBounds()
    return [bounds.width, bounds.height]
  }

  browserWindow.setMinimumSize = function (width, height) {
    const minSize = CGSizeMake(width, height)
    panel.setContentMinSize(minSize)
  }

  browserWindow.getMinimumSize = function () {
    const size = panel.contentMinSize()
    return [size.width, size.height]
  }

  browserWindow.setMaximumSize = function (width, height) {
    const maxSize = CGSizeMake(width, height)
    panel.setContentMaxSize(maxSize)
  }

  browserWindow.getMaximumSize = function () {
    const size = panel.contentMaxSize()
    return [size.width, size.height]
  }

  browserWindow.setResizable = function (resizable) {
    return browserWindow._setStyleMask(resizable, NSResizableWindowMask)
  }

  browserWindow.isResizable = function () {
    return panel.styleMask() & NSResizableWindowMask
  }

  browserWindow.setMovable = function (movable) {
    return panel.setMovable(movable)
  }
  browserWindow.isMovable = function () {
    return panel.isMovable()
  }

  browserWindow.setMinimizable = function (minimizable) {
    return browserWindow._setStyleMask(minimizable, NSMiniaturizableWindowMask)
  }

  browserWindow.isMinimizable = function () {
    return panel.styleMask() & NSMiniaturizableWindowMask
  }

  browserWindow.setMaximizable = function (maximizable) {
    if (panel.standardWindowButton(NSWindowZoomButton)) {
      panel.standardWindowButton(NSWindowZoomButton).setEnabled(maximizable)
    }
  }

  browserWindow.isMaximizable = function () {
    return (
      panel.standardWindowButton(NSWindowZoomButton) &&
      panel.standardWindowButton(NSWindowZoomButton).isEnabled()
    )
  }

  browserWindow.setFullScreenable = function (fullscreenable) {
    browserWindow._setCollectionBehavior(
      fullscreenable,
      NSWindowCollectionBehaviorFullScreenPrimary
    )
    // On EL Capitan this flag is required to hide fullscreen button.
    browserWindow._setCollectionBehavior(
      !fullscreenable,
      NSWindowCollectionBehaviorFullScreenAuxiliary
    )
  }

  browserWindow.isFullScreenable = function () {
    var collectionBehavior = panel.collectionBehavior()
    return collectionBehavior & NSWindowCollectionBehaviorFullScreenPrimary
  }

  browserWindow.setClosable = function (closable) {
    browserWindow._setStyleMask(closable, NSClosableWindowMask)
  }

  browserWindow.isClosable = function () {
    return panel.styleMask() & NSClosableWindowMask
  }

  browserWindow.setAlwaysOnTop = function (top, level, relativeLevel) {
    var windowLevel = NSNormalWindowLevel
    var maxWindowLevel = CGWindowLevelForKey(kCGMaximumWindowLevelKey)
    var minWindowLevel = CGWindowLevelForKey(kCGMinimumWindowLevelKey)

    if (top) {
      if (level === 'normal') {
        windowLevel = NSNormalWindowLevel
      } else if (level === 'torn-off-menu') {
        windowLevel = NSTornOffMenuWindowLevel
      } else if (level === 'modal-panel') {
        windowLevel = NSModalPanelWindowLevel
      } else if (level === 'main-menu') {
        windowLevel = NSMainMenuWindowLevel
      } else if (level === 'status') {
        windowLevel = NSStatusWindowLevel
      } else if (level === 'pop-up-menu') {
        windowLevel = NSPopUpMenuWindowLevel
      } else if (level === 'screen-saver') {
        windowLevel = NSScreenSaverWindowLevel
      } else if (level === 'dock') {
        // Deprecated by macOS, but kept for backwards compatibility
        windowLevel = NSDockWindowLevel
      } else {
        windowLevel = NSFloatingWindowLevel
      }
    }

    var newLevel = windowLevel + (relativeLevel || 0)
    if (newLevel >= minWindowLevel && newLevel <= maxWindowLevel) {
      panel.setLevel(newLevel)
    } else {
      throw new Error(
        'relativeLevel must be between ' +
          minWindowLevel +
          ' and ' +
          maxWindowLevel
      )
    }
  }

  browserWindow.isAlwaysOnTop = function () {
    return panel.level() !== NSNormalWindowLevel
  }

  browserWindow.moveTop = function () {
    return panel.orderFrontRegardless()
  }

  browserWindow.center = function () {
    panel.center()
  }

  browserWindow.setPosition = function (x, y, animate) {
    return browserWindow.setBounds({ x: x, y: y }, animate)
  }

  browserWindow.getPosition = function () {
    var bounds = browserWindow.getBounds()
    return [bounds.x, bounds.y]
  }

  browserWindow.setTitle = function (title) {
    panel.setTitle(title)
  }

  browserWindow.getTitle = function () {
    return String(panel.title())
  }

  var attentionRequestId = 0
  browserWindow.flashFrame = function (flash) {
    if (flash) {
      attentionRequestId = NSApp.requestUserAttention(NSInformationalRequest)
    } else {
      NSApp.cancelUserAttentionRequest(attentionRequestId)
      attentionRequestId = 0
    }
  }

  browserWindow.getNativeWindowHandle = function () {
    return panel
  }

  browserWindow.getNativeWebViewHandle = function () {
    return webview
  }

  browserWindow.loadURL = function (url) {
    // When frameLocation is a file, prefix it with the Sketch Resources path
    if (/^(?!https?|file).*\.html?$/.test(url)) {
      if (typeof __command !== 'undefined' && __command.pluginBundle()) {
        url =
          'file://' + __command.pluginBundle().urlForResourceNamed(url).path()
      }
    }

    if (/^file:\/\/.*\.html?$/.test(url)) {
      // ensure URLs containing spaces are properly handled
      url = NSString.alloc().initWithString(url)
      url = url.stringByAddingPercentEncodingWithAllowedCharacters(
        NSCharacterSet.URLQueryAllowedCharacterSet()
      )
      webview.loadFileURL_allowingReadAccessToURL(
        NSURL.URLWithString(url),
        NSURL.URLWithString('file:///')
      )
      return
    }

    const properURL = NSURL.URLWithString(url)
    const urlRequest = NSURLRequest.requestWithURL(properURL)

    webview.loadRequest(urlRequest)
  }

  browserWindow.reload = function () {
    webview.reload()
  }

  browserWindow.setHasShadow = function (hasShadow) {
    return panel.setHasShadow(hasShadow)
  }

  browserWindow.hasShadow = function () {
    return panel.hasShadow()
  }

  browserWindow.setOpacity = function (opacity) {
    return panel.setAlphaValue(opacity)
  }

  browserWindow.getOpacity = function () {
    return panel.alphaValue()
  }

  browserWindow.setVisibleOnAllWorkspaces = function (visible) {
    return browserWindow._setCollectionBehavior(
      visible,
      NSWindowCollectionBehaviorCanJoinAllSpaces
    )
  }

  browserWindow.isVisibleOnAllWorkspaces = function () {
    var collectionBehavior = panel.collectionBehavior()
    return collectionBehavior & NSWindowCollectionBehaviorCanJoinAllSpaces
  }

  browserWindow.setIgnoreMouseEvents = function (ignore) {
    return panel.setIgnoresMouseEvents(ignore)
  }

  browserWindow.setContentProtection = function (enable) {
    panel.setSharingType(enable ? NSWindowSharingNone : NSWindowSharingReadOnly)
  }

  browserWindow.setAutoHideCursor = function (autoHide) {
    panel.setDisableAutoHideCursor(autoHide)
  }

  browserWindow.setVibrancy = function (type) {
    var effectView = browserWindow._vibrantView

    if (!type) {
      if (effectView == null) {
        return
      }

      effectView.removeFromSuperview()
      panel.setVibrantView(null)
      return
    }

    if (effectView == null) {
      var contentView = panel.contentView()
      effectView = NSVisualEffectView.alloc().initWithFrame(
        contentView.bounds()
      )
      browserWindow._vibrantView = effectView

      effectView.setAutoresizingMask(NSViewWidthSizable | NSViewHeightSizable)
      effectView.setBlendingMode(NSVisualEffectBlendingModeBehindWindow)
      effectView.setState(NSVisualEffectStateActive)
      effectView.setFrame(contentView.bounds())
      contentView.addSubview_positioned_relativeTo(
        effectView,
        NSWindowBelow,
        null
      )
    }

    var vibrancyType = NSVisualEffectMaterialLight

    if (type === 'appearance-based') {
      vibrancyType = NSVisualEffectMaterialAppearanceBased
    } else if (type === 'light') {
      vibrancyType = NSVisualEffectMaterialLight
    } else if (type === 'dark') {
      vibrancyType = NSVisualEffectMaterialDark
    } else if (type === 'titlebar') {
      vibrancyType = NSVisualEffectMaterialTitlebar
    } else if (type === 'selection') {
      vibrancyType = NSVisualEffectMaterialSelection
    } else if (type === 'menu') {
      vibrancyType = NSVisualEffectMaterialMenu
    } else if (type === 'popover') {
      vibrancyType = NSVisualEffectMaterialPopover
    } else if (type === 'sidebar') {
      vibrancyType = NSVisualEffectMaterialSidebar
    } else if (type === 'medium-light') {
      vibrancyType = NSVisualEffectMaterialMediumLight
    } else if (type === 'ultra-dark') {
      vibrancyType = NSVisualEffectMaterialUltraDark
    }

    effectView.setMaterial(vibrancyType)
  }

  browserWindow._setBackgroundColor = function (colorName) {
    var color = parseHexColor(colorName)
    webview.setValue_forKey(false, 'drawsBackground')
    panel.backgroundColor = color
  }

  browserWindow._invalidate = function () {
    panel.flushWindow()
    panel.contentView().setNeedsDisplay(true)
  }

  browserWindow._setStyleMask = function (on, flag) {
    var wasMaximizable = browserWindow.isMaximizable()
    if (on) {
      panel.setStyleMask(panel.styleMask() | flag)
    } else {
      panel.setStyleMask(panel.styleMask() & ~flag)
    }
    // Change style mask will make the zoom button revert to default, probably
    // a bug of Cocoa or macOS.
    browserWindow.setMaximizable(wasMaximizable)
  }

  browserWindow._setCollectionBehavior = function (on, flag) {
    var wasMaximizable = browserWindow.isMaximizable()
    if (on) {
      panel.setCollectionBehavior(panel.collectionBehavior() | flag)
    } else {
      panel.setCollectionBehavior(panel.collectionBehavior() & ~flag)
    }
    // Change collectionBehavior will make the zoom button revert to default,
    // probably a bug of Cocoa or macOS.
    browserWindow.setMaximizable(wasMaximizable)
  }

  browserWindow._showWindowButton = function (button) {
    var view = panel.standardWindowButton(button)
    view.superview().addSubview_positioned_relative(view, NSWindowAbove, null)
  }
}


/***/ },

/***/ "./node_modules/sketch-module-web-view/lib/constants.js"
/*!**************************************************************!*\
  !*** ./node_modules/sketch-module-web-view/lib/constants.js ***!
  \**************************************************************/
(module) {

module.exports = {
  JS_BRIDGE: '__skpm_sketchBridge',
  JS_BRIDGE_RESULT_SUCCESS: '__skpm_sketchBridge_success',
  JS_BRIDGE_RESULT_ERROR: '__skpm_sketchBridge_error',
  START_MOVING_WINDOW: '__skpm_startMovingWindow',
  EXECUTE_JAVASCRIPT: '__skpm_executeJS',
  EXECUTE_JAVASCRIPT_SUCCESS: '__skpm_executeJS_success_',
  EXECUTE_JAVASCRIPT_ERROR: '__skpm_executeJS_error_',
}


/***/ },

/***/ "./node_modules/sketch-module-web-view/lib/dispatch-first-click.js"
/*!*************************************************************************!*\
  !*** ./node_modules/sketch-module-web-view/lib/dispatch-first-click.js ***!
  \*************************************************************************/
(module) {

var tagsToFocus =
  '["text", "textarea", "date", "datetime-local", "email", "number", "month", "password", "search", "tel", "time", "url", "week" ]'

module.exports = function (webView, event) {
  var point = webView.convertPoint_fromView(event.locationInWindow(), null)
  return (
    'var el = document.elementFromPoint(' + // get the DOM element that match the event
    point.x +
    ', ' +
    point.y +
    '); ' +
    'if (el && el.tagName === "SELECT") {' + // select needs special handling
    '  var event = document.createEvent("MouseEvents");' +
    '  event.initMouseEvent("mousedown", true, true, window);' +
    '  el.dispatchEvent(event);' +
    '} else if (el && ' + // some tags need to be focused instead of clicked
    tagsToFocus +
    '.indexOf(el.type) >= 0 && ' +
    'el.focus' +
    ') {' +
    'el.focus();' + // so focus them
    '} else if (el) {' +
    'el.dispatchEvent(new Event("click", {bubbles: true}))' + // click the others
    '}'
  )
}


/***/ },

/***/ "./node_modules/sketch-module-web-view/lib/execute-javascript.js"
/*!***********************************************************************!*\
  !*** ./node_modules/sketch-module-web-view/lib/execute-javascript.js ***!
  \***********************************************************************/
(module, __unused_webpack_exports, __webpack_require__) {

/* provided dependency */ var Promise = __webpack_require__(/*! ./node_modules/@skpm/promise/index.js */ "./node_modules/@skpm/promise/index.js");
var CONSTANTS = __webpack_require__(/*! ./constants */ "./node_modules/sketch-module-web-view/lib/constants.js")

module.exports = function (webview, browserWindow) {
  function executeJavaScript(script, userGesture, callback) {
    if (typeof userGesture === 'function') {
      callback = userGesture
      userGesture = false
    }
    var fiber = coscript.createFiber()

    // if the webview is not ready yet, defer the execution until it is
    if (
      webview.navigationDelegate().state &&
      webview.navigationDelegate().state.wasReady == 0
    ) {
      return new Promise(function (resolve, reject) {
        browserWindow.once('ready-to-show', function () {
          executeJavaScript(script, userGesture, callback)
            .then(resolve)
            .catch(reject)
          fiber.cleanup()
        })
      })
    }

    return new Promise(function (resolve, reject) {
      var requestId = Math.random()

      browserWindow.webContents.on(
        CONSTANTS.EXECUTE_JAVASCRIPT_SUCCESS + requestId,
        function (res) {
          try {
            if (callback) {
              callback(null, res)
            }
            resolve(res)
          } catch (err) {
            reject(err)
          }
          fiber.cleanup()
        }
      )
      browserWindow.webContents.on(
        CONSTANTS.EXECUTE_JAVASCRIPT_ERROR + requestId,
        function (err) {
          try {
            if (callback) {
              callback(err)
              resolve()
            } else {
              reject(err)
            }
          } catch (err2) {
            reject(err2)
          }
          fiber.cleanup()
        }
      )

      webview.evaluateJavaScript_completionHandler(
        module.exports.wrapScript(script, requestId),
        null
      )
    })
  }

  return executeJavaScript
}

module.exports.wrapScript = function (script, requestId) {
  return (
    'window.' +
    CONSTANTS.EXECUTE_JAVASCRIPT +
    '(' +
    requestId +
    ', ' +
    JSON.stringify(script) +
    ')'
  )
}

module.exports.injectScript = function (webView) {
  var source =
    'window.' +
    CONSTANTS.EXECUTE_JAVASCRIPT +
    ' = function(id, script) {' +
    '  try {' +
    '    var res = eval(script);' +
    '    if (res && typeof res.then === "function" && typeof res.catch === "function") {' +
    '      res.then(function (res2) {' +
    '        window.postMessage("' +
    CONSTANTS.EXECUTE_JAVASCRIPT_SUCCESS +
    '" + id, res2);' +
    '      })' +
    '      .catch(function (err) {' +
    '        window.postMessage("' +
    CONSTANTS.EXECUTE_JAVASCRIPT_ERROR +
    '" + id, err);' +
    '      })' +
    '    } else {' +
    '      window.postMessage("' +
    CONSTANTS.EXECUTE_JAVASCRIPT_SUCCESS +
    '" + id, res);' +
    '    }' +
    '  } catch (err) {' +
    '    window.postMessage("' +
    CONSTANTS.EXECUTE_JAVASCRIPT_ERROR +
    '" + id, err);' +
    '  }' +
    '}'
  var script =
    WKUserScript.alloc().initWithSource_injectionTime_forMainFrameOnly(
      source,
      0,
      true
    )
  webView.configuration().userContentController().addUserScript(script)
}


/***/ },

/***/ "./node_modules/sketch-module-web-view/lib/fitSubview.js"
/*!***************************************************************!*\
  !*** ./node_modules/sketch-module-web-view/lib/fitSubview.js ***!
  \***************************************************************/
(module) {

function addEdgeConstraint(edge, subview, view, constant) {
  view.addConstraint(
    NSLayoutConstraint.constraintWithItem_attribute_relatedBy_toItem_attribute_multiplier_constant(
      subview,
      edge,
      NSLayoutRelationEqual,
      view,
      edge,
      1,
      constant
    )
  )
}
module.exports = function fitSubviewToView(subview, view, constants) {
  constants = constants || []
  subview.setTranslatesAutoresizingMaskIntoConstraints(false)

  addEdgeConstraint(NSLayoutAttributeLeft, subview, view, constants[0] || 0)
  addEdgeConstraint(NSLayoutAttributeTop, subview, view, constants[1] || 0)
  addEdgeConstraint(NSLayoutAttributeRight, subview, view, constants[2] || 0)
  addEdgeConstraint(NSLayoutAttributeBottom, subview, view, constants[3] || 0)
}


/***/ },

/***/ "./node_modules/sketch-module-web-view/lib/index.js"
/*!**********************************************************!*\
  !*** ./node_modules/sketch-module-web-view/lib/index.js ***!
  \**********************************************************/
(module, __unused_webpack_exports, __webpack_require__) {

/* let's try to match the API from Electron's Browser window
(https://github.com/electron/electron/blob/master/docs/api/browser-window.md) */
var EventEmitter = __webpack_require__(/*! events */ "events")
var buildBrowserAPI = __webpack_require__(/*! ./browser-api */ "./node_modules/sketch-module-web-view/lib/browser-api.js")
var buildWebAPI = __webpack_require__(/*! ./webview-api */ "./node_modules/sketch-module-web-view/lib/webview-api.js")
var fitSubviewToView = __webpack_require__(/*! ./fitSubview */ "./node_modules/sketch-module-web-view/lib/fitSubview.js")
var dispatchFirstClick = __webpack_require__(/*! ./dispatch-first-click */ "./node_modules/sketch-module-web-view/lib/dispatch-first-click.js")
var injectClientMessaging = __webpack_require__(/*! ./inject-client-messaging */ "./node_modules/sketch-module-web-view/lib/inject-client-messaging.js")
var movableArea = __webpack_require__(/*! ./movable-area */ "./node_modules/sketch-module-web-view/lib/movable-area.js")
var executeJavaScript = __webpack_require__(/*! ./execute-javascript */ "./node_modules/sketch-module-web-view/lib/execute-javascript.js")
var setDelegates = __webpack_require__(/*! ./set-delegates */ "./node_modules/sketch-module-web-view/lib/set-delegates.js")

function BrowserWindow(options) {
  options = options || {}

  var identifier = options.identifier || String(NSUUID.UUID().UUIDString())
  var threadDictionary = NSThread.mainThread().threadDictionary()

  var existingBrowserWindow = BrowserWindow.fromId(identifier)

  // if we already have a window opened, reuse it
  if (existingBrowserWindow) {
    return existingBrowserWindow
  }

  var browserWindow = new EventEmitter()
  browserWindow.id = identifier

  if (options.modal && !options.parent) {
    throw new Error('A modal needs to have a parent.')
  }

  // Long-running script
  var fiber = coscript.createFiber()

  // Window size
  var width = options.width || 800
  var height = options.height || 600
  var mainScreenRect = NSScreen.screens().firstObject().frame()
  var cocoaBounds = NSMakeRect(
    typeof options.x !== 'undefined'
      ? options.x
      : Math.round((NSWidth(mainScreenRect) - width) / 2),
    typeof options.y !== 'undefined'
      ? NSHeight(mainScreenRect) - options.y
      : Math.round((NSHeight(mainScreenRect) - height) / 2),
    width,
    height
  )

  if (options.titleBarStyle && options.titleBarStyle !== 'default') {
    options.frame = false
  }

  var useStandardWindow = options.windowType !== 'textured'
  var styleMask = NSTitledWindowMask

  // this is commented out because the toolbar doesn't appear otherwise :thinking-face:
  // if (!useStandardWindow || options.frame === false) {
  //   styleMask = NSFullSizeContentViewWindowMask
  // }
  if (options.minimizable !== false) {
    styleMask |= NSMiniaturizableWindowMask
  }
  if (options.closable !== false) {
    styleMask |= NSClosableWindowMask
  }
  if (options.resizable !== false) {
    styleMask |= NSResizableWindowMask
  }
  if (!useStandardWindow || options.transparent || options.frame === false) {
    styleMask |= NSTexturedBackgroundWindowMask
  }

  var panel = NSPanel.alloc().initWithContentRect_styleMask_backing_defer(
    cocoaBounds,
    styleMask,
    NSBackingStoreBuffered,
    true
  )

  // this would be nice but it's crashing on macOS 11.0
  // panel.releasedWhenClosed = true

  var wkwebviewConfig = WKWebViewConfiguration.alloc().init()
  var webView = WKWebView.alloc().initWithFrame_configuration(
    CGRectMake(0, 0, options.width || 800, options.height || 600),
    wkwebviewConfig
  )
  injectClientMessaging(webView)
  webView.setAutoresizingMask(NSViewWidthSizable | NSViewHeightSizable)

  buildBrowserAPI(browserWindow, panel, webView)
  buildWebAPI(browserWindow, panel, webView)
  setDelegates(browserWindow, panel, webView, options)

  if (options.windowType === 'desktop') {
    panel.setLevel(kCGDesktopWindowLevel - 1)
    // panel.setCanBecomeKeyWindow(false)
    panel.setCollectionBehavior(
      NSWindowCollectionBehaviorCanJoinAllSpaces |
        NSWindowCollectionBehaviorStationary |
        NSWindowCollectionBehaviorIgnoresCycle
    )
  }

  if (
    typeof options.minWidth !== 'undefined' ||
    typeof options.minHeight !== 'undefined'
  ) {
    browserWindow.setMinimumSize(options.minWidth || 0, options.minHeight || 0)
  }

  if (
    typeof options.maxWidth !== 'undefined' ||
    typeof options.maxHeight !== 'undefined'
  ) {
    browserWindow.setMaximumSize(
      options.maxWidth || 10000,
      options.maxHeight || 10000
    )
  }

  // if (options.focusable === false) {
  //   panel.setCanBecomeKeyWindow(false)
  // }

  if (options.transparent || options.frame === false) {
    panel.titlebarAppearsTransparent = true
    panel.titleVisibility = NSWindowTitleHidden
    panel.setOpaque(0)
    panel.isMovableByWindowBackground = true
    var toolbar2 = NSToolbar.alloc().initWithIdentifier(
      'titlebarStylingToolbar'
    )
    toolbar2.setShowsBaselineSeparator(false)
    panel.setToolbar(toolbar2)
  }

  if (options.titleBarStyle === 'hiddenInset') {
    var toolbar = NSToolbar.alloc().initWithIdentifier('titlebarStylingToolbar')
    toolbar.setShowsBaselineSeparator(false)
    panel.setToolbar(toolbar)
  }

  if (options.frame === false || !options.useContentSize) {
    browserWindow.setSize(width, height)
  }

  if (options.center) {
    browserWindow.center()
  }

  if (options.alwaysOnTop) {
    browserWindow.setAlwaysOnTop(true)
  }

  if (options.fullscreen) {
    browserWindow.setFullScreen(true)
  }
  browserWindow.setFullScreenable(!!options.fullscreenable)

  let title = options.title
  if (options.frame === false) {
    title = undefined
  } else if (
    typeof title === 'undefined' &&
    typeof __command !== 'undefined' &&
    __command.pluginBundle()
  ) {
    title = __command.pluginBundle().name()
  }

  if (title) {
    browserWindow.setTitle(title)
  }

  var backgroundColor = options.backgroundColor
  if (options.transparent) {
    backgroundColor = NSColor.clearColor()
  }
  if (!backgroundColor && options.frame === false && options.vibrancy) {
    backgroundColor = NSColor.clearColor()
  }

  browserWindow._setBackgroundColor(
    backgroundColor || NSColor.windowBackgroundColor()
  )

  if (options.hasShadow === false) {
    browserWindow.setHasShadow(false)
  }

  if (typeof options.opacity !== 'undefined') {
    browserWindow.setOpacity(options.opacity)
  }

  options.webPreferences = options.webPreferences || {}

  webView
    .configuration()
    .preferences()
    .setValue_forKey(
      options.webPreferences.devTools !== false,
      'developerExtrasEnabled'
    )
  webView
    .configuration()
    .preferences()
    .setValue_forKey(
      options.webPreferences.javascript !== false,
      'javaScriptEnabled'
    )
  webView
    .configuration()
    .preferences()
    .setValue_forKey(!!options.webPreferences.plugins, 'plugInsEnabled')
  webView
    .configuration()
    .preferences()
    .setValue_forKey(
      options.webPreferences.minimumFontSize || 0,
      'minimumFontSize'
    )

  if (options.webPreferences.zoomFactor) {
    webView.setMagnification(options.webPreferences.zoomFactor)
  }

  var contentView = panel.contentView()

  if (options.frame !== false) {
    webView.setFrame(contentView.bounds())
    contentView.addSubview(webView)
  } else {
    // In OSX 10.10, adding subviews to the root view for the NSView hierarchy
    // produces warnings. To eliminate the warnings, we resize the contentView
    // to fill the window, and add subviews to that.
    // http://crbug.com/380412
    contentView.setAutoresizingMask(NSViewWidthSizable | NSViewHeightSizable)
    fitSubviewToView(contentView, contentView.superview())

    webView.setFrame(contentView.bounds())
    contentView.addSubview(webView)

    // The fullscreen button should always be hidden for frameless window.
    if (panel.standardWindowButton(NSWindowFullScreenButton)) {
      panel.standardWindowButton(NSWindowFullScreenButton).setHidden(true)
    }

    if (!options.titleBarStyle || options.titleBarStyle === 'default') {
      // Hide the window buttons.
      panel.standardWindowButton(NSWindowZoomButton).setHidden(true)
      panel.standardWindowButton(NSWindowMiniaturizeButton).setHidden(true)
      panel.standardWindowButton(NSWindowCloseButton).setHidden(true)

      // Some third-party macOS utilities check the zoom button's enabled state to
      // determine whether to show custom UI on hover, so we disable it here to
      // prevent them from doing so in a frameless app window.
      panel.standardWindowButton(NSWindowZoomButton).setEnabled(false)
    }
  }

  if (options.vibrancy) {
    browserWindow.setVibrancy(options.vibrancy)
  }

  // Set maximizable state last to ensure zoom button does not get reset
  // by calls to other APIs.
  browserWindow.setMaximizable(options.maximizable !== false)

  panel.setHidesOnDeactivate(options.hidesOnDeactivate !== false)

  if (options.remembersWindowFrame) {
    panel.setFrameAutosaveName(identifier)
    panel.setFrameUsingName_force(panel.frameAutosaveName(), false)
  }

  if (options.acceptsFirstMouse) {
    browserWindow.on('focus', function (event) {
      if (event.type() === NSEventTypeLeftMouseDown) {
        browserWindow.webContents
          .executeJavaScript(dispatchFirstClick(webView, event))
          .catch(() => {})
      }
    })
  }

  executeJavaScript.injectScript(webView)
  movableArea.injectScript(webView)
  movableArea.setupHandler(browserWindow)

  if (options.show !== false) {
    browserWindow.show()
  }

  browserWindow.on('closed', function () {
    browserWindow._destroyed = true
    threadDictionary.removeObjectForKey(identifier)
    var observer = threadDictionary[identifier + '.themeObserver']
    if (observer) {
      NSApplication.sharedApplication().removeObserver_forKeyPath(
        observer,
        'effectiveAppearance'
      )
      threadDictionary.removeObjectForKey(identifier + '.themeObserver')
    }
    fiber.cleanup()
  })

  threadDictionary[identifier] = panel

  fiber.onCleanup(function () {
    if (!browserWindow._destroyed) {
      browserWindow.destroy()
    }
  })

  return browserWindow
}

BrowserWindow.fromId = function (identifier) {
  var threadDictionary = NSThread.mainThread().threadDictionary()

  if (threadDictionary[identifier]) {
    return BrowserWindow.fromPanel(threadDictionary[identifier], identifier)
  }

  return undefined
}

BrowserWindow.fromPanel = function (panel, identifier) {
  var browserWindow = new EventEmitter()
  browserWindow.id = identifier

  if (!panel || !panel.contentView) {
    throw new Error('needs to pass an NSPanel')
  }

  var webView = null
  var subviews = panel.contentView().subviews()
  for (var i = 0; i < subviews.length; i += 1) {
    if (
      !webView &&
      !subviews[i].isKindOfClass(WKInspectorWKWebView) &&
      subviews[i].isKindOfClass(WKWebView)
    ) {
      webView = subviews[i]
    }
  }

  if (!webView) {
    throw new Error('The panel needs to have a webview')
  }

  buildBrowserAPI(browserWindow, panel, webView)
  buildWebAPI(browserWindow, panel, webView)
  // FIXME: we should be able to provide the actual options here instead of
  // an empty object, but we can't persist them via NSThread.threadDictionary()
  // as it's not an Objective-C object
  setDelegates(browserWindow, panel, webView, {})

  return browserWindow
}

module.exports = BrowserWindow


/***/ },

/***/ "./node_modules/sketch-module-web-view/lib/inject-client-messaging.js"
/*!****************************************************************************!*\
  !*** ./node_modules/sketch-module-web-view/lib/inject-client-messaging.js ***!
  \****************************************************************************/
(module, __unused_webpack_exports, __webpack_require__) {

var CONSTANTS = __webpack_require__(/*! ./constants */ "./node_modules/sketch-module-web-view/lib/constants.js")

module.exports = function (webView) {
  var source =
    'window.originalPostMessage = window.postMessage;' +
    'window.postMessage = function(actionName) {' +
    '  if (!actionName) {' +
    "    throw new Error('missing action name')" +
    '  }' +
    '  var id = String(Math.random()).replace(".", "");' +
    '    var args = [].slice.call(arguments);' +
    '    args.unshift(id);' +
    '  return new Promise(function (resolve, reject) {' +
    '    window["' +
    CONSTANTS.JS_BRIDGE_RESULT_SUCCESS +
    '" + id] = resolve;' +
    '    window["' +
    CONSTANTS.JS_BRIDGE_RESULT_ERROR +
    '" + id] = reject;' +
    '    window.webkit.messageHandlers.' +
    CONSTANTS.JS_BRIDGE +
    '.postMessage(JSON.stringify(args));' +
    '  });' +
    '}'
  var script =
    WKUserScript.alloc().initWithSource_injectionTime_forMainFrameOnly(
      source,
      0,
      true
    )
  webView.configuration().userContentController().addUserScript(script)
}


/***/ },

/***/ "./node_modules/sketch-module-web-view/lib/movable-area.js"
/*!*****************************************************************!*\
  !*** ./node_modules/sketch-module-web-view/lib/movable-area.js ***!
  \*****************************************************************/
(module, __unused_webpack_exports, __webpack_require__) {

var CONSTANTS = __webpack_require__(/*! ./constants */ "./node_modules/sketch-module-web-view/lib/constants.js")

module.exports.injectScript = function (webView) {
  var source =
    '(function () {' +
    "document.addEventListener('mousedown', onMouseDown);" +
    '' +
    'function shouldDrag(target) {' +
    '  if (!target || (target.dataset || {}).appRegion === "no-drag") { return false }' +
    '  if ((target.dataset || {}).appRegion === "drag") { return true }' +
    '  return shouldDrag(target.parentElement)' +
    '};' +
    '' +
    'function onMouseDown(e) {' +
    '  if (e.button !== 0 || !shouldDrag(e.target)) { return }' +
    '  window.postMessage("' +
    CONSTANTS.START_MOVING_WINDOW +
    '");' +
    '};' +
    '})()'
  var script =
    WKUserScript.alloc().initWithSource_injectionTime_forMainFrameOnly(
      source,
      0,
      true
    )
  webView.configuration().userContentController().addUserScript(script)
}

module.exports.setupHandler = function (browserWindow) {
  var initialMouseLocation = null
  var initialWindowPosition = null
  var interval = null

  function moveWindow() {
    // if the user released the button, stop moving the window
    if (!initialWindowPosition || NSEvent.pressedMouseButtons() !== 1) {
      clearInterval(interval)
      initialMouseLocation = null
      initialWindowPosition = null
      return
    }

    var mouse = NSEvent.mouseLocation()
    browserWindow.setPosition(
      initialWindowPosition.x + (mouse.x - initialMouseLocation.x),
      initialWindowPosition.y + (initialMouseLocation.y - mouse.y), // y is inverted
      false
    )
  }

  browserWindow.webContents.on(CONSTANTS.START_MOVING_WINDOW, function () {
    initialMouseLocation = NSEvent.mouseLocation()
    var position = browserWindow.getPosition()
    initialWindowPosition = {
      x: position[0],
      y: position[1],
    }

    interval = setInterval(moveWindow, 1000 / 60) // 60 fps
  })
}


/***/ },

/***/ "./node_modules/sketch-module-web-view/lib/parseWebArguments.js"
/*!**********************************************************************!*\
  !*** ./node_modules/sketch-module-web-view/lib/parseWebArguments.js ***!
  \**********************************************************************/
(module) {

module.exports = function (webArguments) {
  var args = null
  try {
    args = JSON.parse(webArguments)
  } catch (e) {
    // malformed arguments
  }

  if (
    !args ||
    !args.constructor ||
    args.constructor !== Array ||
    args.length == 0
  ) {
    return null
  }

  return args
}


/***/ },

/***/ "./node_modules/sketch-module-web-view/lib/set-delegates.js"
/*!******************************************************************!*\
  !*** ./node_modules/sketch-module-web-view/lib/set-delegates.js ***!
  \******************************************************************/
(module, __unused_webpack_exports, __webpack_require__) {

/* provided dependency */ var Promise = __webpack_require__(/*! ./node_modules/@skpm/promise/index.js */ "./node_modules/@skpm/promise/index.js");
var ObjCClass = __webpack_require__(/*! mocha-js-delegate */ "./node_modules/mocha-js-delegate/index.js")
var parseWebArguments = __webpack_require__(/*! ./parseWebArguments */ "./node_modules/sketch-module-web-view/lib/parseWebArguments.js")
var CONSTANTS = __webpack_require__(/*! ./constants */ "./node_modules/sketch-module-web-view/lib/constants.js")

// We create one ObjC class for ourselves here
var WindowDelegateClass
var NavigationDelegateClass
var WebScriptHandlerClass
var ThemeObserverClass

// TODO: events
// - 'page-favicon-updated'
// - 'new-window'
// - 'did-navigate-in-page'
// - 'will-prevent-unload'
// - 'crashed'
// - 'unresponsive'
// - 'responsive'
// - 'destroyed'
// - 'before-input-event'
// - 'certificate-error'
// - 'found-in-page'
// - 'media-started-playing'
// - 'media-paused'
// - 'did-change-theme-color'
// - 'update-target-url'
// - 'cursor-changed'
// - 'context-menu'
// - 'select-bluetooth-device'
// - 'paint'
// - 'console-message'

module.exports = function (browserWindow, panel, webview, options) {
  if (!ThemeObserverClass) {
    ThemeObserverClass = new ObjCClass({
      utils: null,

      'observeValueForKeyPath:ofObject:change:context:': function (
        keyPath,
        object,
        change
      ) {
        const newAppearance = change[NSKeyValueChangeNewKey]
        const isDark =
          String(
            newAppearance.bestMatchFromAppearancesWithNames([
              'NSAppearanceNameAqua',
              'NSAppearanceNameDarkAqua',
            ])
          ) === 'NSAppearanceNameDarkAqua'

        this.utils.executeJavaScript(
          "document.body.classList.remove('__skpm-" +
            (isDark ? 'light' : 'dark') +
            "'); document.body.classList.add('__skpm-" +
            (isDark ? 'dark' : 'light') +
            "')"
        )
      },
    })
  }

  if (!WindowDelegateClass) {
    WindowDelegateClass = new ObjCClass({
      utils: null,
      panel: null,

      'windowDidResize:': function () {
        this.utils.emit('resize')
      },

      'windowDidMiniaturize:': function () {
        this.utils.emit('minimize')
      },

      'windowDidDeminiaturize:': function () {
        this.utils.emit('restore')
      },

      'windowDidEnterFullScreen:': function () {
        this.utils.emit('enter-full-screen')
      },

      'windowDidExitFullScreen:': function () {
        this.utils.emit('leave-full-screen')
      },

      'windowDidMove:': function () {
        this.utils.emit('move')
        this.utils.emit('moved')
      },

      'windowShouldClose:': function () {
        var shouldClose = 1
        this.utils.emit('close', {
          get defaultPrevented() {
            return !shouldClose
          },
          preventDefault: function () {
            shouldClose = 0
          },
        })
        return shouldClose
      },

      'windowWillClose:': function () {
        this.utils.emit('closed')
      },

      'windowDidBecomeKey:': function () {
        this.utils.emit('focus', this.panel.currentEvent())
      },

      'windowDidResignKey:': function () {
        this.utils.emit('blur')
      },
    })
  }

  if (!NavigationDelegateClass) {
    NavigationDelegateClass = new ObjCClass({
      state: {
        wasReady: 0,
      },
      utils: null,

      // // Called when the web view begins to receive web content.
      'webView:didCommitNavigation:': function (webView) {
        this.utils.emit('will-navigate', {}, String(String(webView.URL())))
      },

      // // Called when web content begins to load in a web view.
      'webView:didStartProvisionalNavigation:': function () {
        this.utils.emit('did-start-navigation')
        this.utils.emit('did-start-loading')
      },

      // Called when a web view receives a server redirect.
      'webView:didReceiveServerRedirectForProvisionalNavigation:': function () {
        this.utils.emit('did-get-redirect-request')
      },

      // // Called when the web view needs to respond to an authentication challenge.
      // 'webView:didReceiveAuthenticationChallenge:completionHandler:': function(
      //   webView,
      //   challenge,
      //   completionHandler
      // ) {
      //   function callback(username, password) {
      //     completionHandler(
      //       0,
      //       NSURLCredential.credentialWithUser_password_persistence(
      //         username,
      //         password,
      //         1
      //       )
      //     )
      //   }
      //   var protectionSpace = challenge.protectionSpace()
      //   this.utils.emit(
      //     'login',
      //     {},
      //     {
      //       method: String(protectionSpace.authenticationMethod()),
      //       url: 'not implemented', // TODO:
      //       referrer: 'not implemented', // TODO:
      //     },
      //     {
      //       isProxy: !!protectionSpace.isProxy(),
      //       scheme: String(protectionSpace.protocol()),
      //       host: String(protectionSpace.host()),
      //       port: Number(protectionSpace.port()),
      //       realm: String(protectionSpace.realm()),
      //     },
      //     callback
      //   )
      // },

      // Called when an error occurs during navigation.
      // 'webView:didFailNavigation:withError:': function(
      //   webView,
      //   navigation,
      //   error
      // ) {},

      // Called when an error occurs while the web view is loading content.
      'webView:didFailProvisionalNavigation:withError:': function (
        webView,
        navigation,
        error
      ) {
        this.utils.emit('did-fail-load', error)
      },

      // Called when the navigation is complete.
      'webView:didFinishNavigation:': function () {
        if (this.state.wasReady == 0) {
          this.state.wasReady = 1
          this.utils.emitBrowserEvent('ready-to-show')
        }
        this.utils.emit('did-navigate')
        this.utils.emit('did-frame-navigate')
        this.utils.emit('did-stop-loading')
        this.utils.emit('did-finish-load')
        this.utils.emit('did-frame-finish-load')
      },

      // Called when the web view’s web content process is terminated.
      'webViewWebContentProcessDidTerminate:': function () {
        this.utils.emit('dom-ready')
      },

      // Decides whether to allow or cancel a navigation.
      // webView:decidePolicyForNavigationAction:decisionHandler:

      // Decides whether to allow or cancel a navigation after its response is known.
      // webView:decidePolicyForNavigationResponse:decisionHandler:
    })
  }

  if (!WebScriptHandlerClass) {
    WebScriptHandlerClass = new ObjCClass({
      utils: null,
      'userContentController:didReceiveScriptMessage:': function (_, message) {
        var args = this.utils.parseWebArguments(String(message.body()))
        if (!args) {
          return
        }
        if (!args[0] || typeof args[0] !== 'string') {
          return
        }
        args[0] = String(args[0])

        this.utils.emit.apply(this, args)
      },
    })
  }

  var themeObserver = ThemeObserverClass.new({
    utils: {
      executeJavaScript(script) {
        webview.evaluateJavaScript_completionHandler(script, null)
      },
    },
  })

  var script =
    WKUserScript.alloc().initWithSource_injectionTime_forMainFrameOnly(
      "document.addEventListener('DOMContentLoaded', function() { document.body.classList.add('__skpm-" +
        (typeof MSTheme !== 'undefined' && MSTheme.sharedTheme().isDark()
          ? 'dark'
          : 'light') +
        "') }, false)",
      0,
      true
    )
  webview.configuration().userContentController().addUserScript(script)

  NSApplication.sharedApplication().addObserver_forKeyPath_options_context(
    themeObserver,
    'effectiveAppearance',
    NSKeyValueObservingOptionNew,
    null
  )

  var threadDictionary = NSThread.mainThread().threadDictionary()
  threadDictionary[browserWindow.id + '.themeObserver'] = themeObserver

  var navigationDelegate = NavigationDelegateClass.new({
    utils: {
      setTitle: browserWindow.setTitle.bind(browserWindow),
      emitBrowserEvent() {
        try {
          browserWindow.emit.apply(browserWindow, arguments)
        } catch (err) {
          if (
            typeof process !== 'undefined' &&
            process.listenerCount &&
            process.listenerCount('uncaughtException')
          ) {
            process.emit('uncaughtException', err, 'uncaughtException')
          } else {
            console.error(err)
            throw err
          }
        }
      },
      emit() {
        try {
          browserWindow.webContents.emit.apply(
            browserWindow.webContents,
            arguments
          )
        } catch (err) {
          if (
            typeof process !== 'undefined' &&
            process.listenerCount &&
            process.listenerCount('uncaughtException')
          ) {
            process.emit('uncaughtException', err, 'uncaughtException')
          } else {
            console.error(err)
            throw err
          }
        }
      },
    },
    state: {
      wasReady: 0,
    },
  })

  webview.setNavigationDelegate(navigationDelegate)

  var webScriptHandler = WebScriptHandlerClass.new({
    utils: {
      emit(id, type) {
        if (!type) {
          webview.evaluateJavaScript_completionHandler(
            CONSTANTS.JS_BRIDGE_RESULT_SUCCESS + id + '()',
            null
          )
          return
        }

        var args = []
        for (var i = 2; i < arguments.length; i += 1) args.push(arguments[i])

        var listeners = browserWindow.webContents.listeners(type)

        Promise.all(
          listeners.map(function (l) {
            return Promise.resolve().then(function () {
              return l.apply(l, args)
            })
          })
        )
          .then(function (res) {
            webview.evaluateJavaScript_completionHandler(
              CONSTANTS.JS_BRIDGE_RESULT_SUCCESS +
                id +
                '(' +
                JSON.stringify(res) +
                ')',
              null
            )
          })
          .catch(function (err) {
            webview.evaluateJavaScript_completionHandler(
              CONSTANTS.JS_BRIDGE_RESULT_ERROR +
                id +
                '(' +
                JSON.stringify(err) +
                ')',
              null
            )
          })
      },
      parseWebArguments: parseWebArguments,
    },
  })

  webview
    .configuration()
    .userContentController()
    .addScriptMessageHandler_name(webScriptHandler, CONSTANTS.JS_BRIDGE)

  var utils = {
    emit() {
      try {
        browserWindow.emit.apply(browserWindow, arguments)
      } catch (err) {
        if (
          typeof process !== 'undefined' &&
          process.listenerCount &&
          process.listenerCount('uncaughtException')
        ) {
          process.emit('uncaughtException', err, 'uncaughtException')
        } else {
          console.error(err)
          throw err
        }
      }
    },
  }
  if (options.modal) {
    // find the window of the document
    var msdocument
    if (options.parent.type === 'Document') {
      msdocument = options.parent.sketchObject
    } else {
      msdocument = options.parent
    }
    if (msdocument && String(msdocument.class()) === 'MSDocumentData') {
      // we only have an MSDocumentData instead of a MSDocument
      // let's try to get back to the MSDocument
      msdocument = msdocument.delegate()
    }
    utils.parentWindow = msdocument.windowForSheet()
  }

  var windowDelegate = WindowDelegateClass.new({
    utils: utils,
    panel: panel,
  })

  panel.setDelegate(windowDelegate)
}


/***/ },

/***/ "./node_modules/sketch-module-web-view/lib/webview-api.js"
/*!****************************************************************!*\
  !*** ./node_modules/sketch-module-web-view/lib/webview-api.js ***!
  \****************************************************************/
(module, __unused_webpack_exports, __webpack_require__) {

var EventEmitter = __webpack_require__(/*! events */ "events")
var executeJavaScript = __webpack_require__(/*! ./execute-javascript */ "./node_modules/sketch-module-web-view/lib/execute-javascript.js")

// let's try to match https://github.com/electron/electron/blob/master/docs/api/web-contents.md
module.exports = function buildAPI(browserWindow, panel, webview) {
  var webContents = new EventEmitter()

  webContents.loadURL = browserWindow.loadURL

  webContents.loadFile = function (/* filePath */) {
    // TODO:
    console.warn(
      'Not implemented yet, please open a PR on https://github.com/skpm/sketch-module-web-view :)'
    )
  }

  webContents.downloadURL = function (/* filePath */) {
    // TODO:
    console.warn(
      'Not implemented yet, please open a PR on https://github.com/skpm/sketch-module-web-view :)'
    )
  }

  webContents.getURL = function () {
    return String(webview.URL())
  }

  webContents.getTitle = function () {
    return String(webview.title())
  }

  webContents.isDestroyed = function () {
    // TODO:
    console.warn(
      'Not implemented yet, please open a PR on https://github.com/skpm/sketch-module-web-view :)'
    )
  }

  webContents.focus = browserWindow.focus
  webContents.isFocused = browserWindow.isFocused

  webContents.isLoading = function () {
    return !!webview.loading()
  }

  webContents.isLoadingMainFrame = function () {
    // TODO:
    return !!webview.loading()
  }

  webContents.isWaitingForResponse = function () {
    return !webview.loading()
  }

  webContents.stop = function () {
    webview.stopLoading()
  }
  webContents.reload = function () {
    webview.reload()
  }
  webContents.reloadIgnoringCache = function () {
    webview.reloadFromOrigin()
  }
  webContents.canGoBack = function () {
    return !!webview.canGoBack()
  }
  webContents.canGoForward = function () {
    return !!webview.canGoForward()
  }
  webContents.canGoToOffset = function (offset) {
    return !!webview.backForwardList().itemAtIndex(offset)
  }
  webContents.clearHistory = function () {
    // TODO:
    console.warn(
      'Not implemented yet, please open a PR on https://github.com/skpm/sketch-module-web-view :)'
    )
  }
  webContents.goBack = function () {
    webview.goBack()
  }
  webContents.goForward = function () {
    webview.goForward()
  }
  webContents.goToIndex = function (index) {
    var backForwardList = webview.backForwardList()
    var backList = backForwardList.backList()
    var backListLength = backList.count()
    if (backListLength > index) {
      webview.loadRequest(NSURLRequest.requestWithURL(backList[index]))
      return
    }
    var forwardList = backForwardList.forwardList()
    if (forwardList.count() > index - backListLength) {
      webview.loadRequest(
        NSURLRequest.requestWithURL(forwardList[index - backListLength])
      )
      return
    }
    throw new Error('Cannot go to index ' + index)
  }
  webContents.goToOffset = function (offset) {
    if (!webContents.canGoToOffset(offset)) {
      throw new Error('Cannot go to offset ' + offset)
    }
    webview.loadRequest(
      NSURLRequest.requestWithURL(webview.backForwardList().itemAtIndex(offset))
    )
  }
  webContents.isCrashed = function () {
    // TODO:
    console.warn(
      'Not implemented yet, please open a PR on https://github.com/skpm/sketch-module-web-view :)'
    )
  }
  webContents.setUserAgent = function (/* userAgent */) {
    // TODO:
    console.warn(
      'Not implemented yet, please open a PR on https://github.com/skpm/sketch-module-web-view :)'
    )
  }
  webContents.getUserAgent = function () {
    const userAgent = webview.customUserAgent()
    return userAgent ? String(userAgent) : undefined
  }
  webContents.insertCSS = function (css) {
    var source =
      "var style = document.createElement('style'); style.innerHTML = " +
      css.replace(/"/, '\\"') +
      '; document.head.appendChild(style);'
    var script =
      WKUserScript.alloc().initWithSource_injectionTime_forMainFrameOnly(
        source,
        0,
        true
      )
    webview.configuration().userContentController().addUserScript(script)
  }
  webContents.insertJS = function (source) {
    var script =
      WKUserScript.alloc().initWithSource_injectionTime_forMainFrameOnly(
        source,
        0,
        true
      )
    webview.configuration().userContentController().addUserScript(script)
  }
  webContents.executeJavaScript = executeJavaScript(webview, browserWindow)
  webContents.setIgnoreMenuShortcuts = function () {
    // TODO:??
    console.warn(
      'Not implemented yet, please open a PR on https://github.com/skpm/sketch-module-web-view :)'
    )
  }
  webContents.setAudioMuted = function (/* muted */) {
    // TODO:??
    console.warn(
      'Not implemented yet, please open a PR on https://github.com/skpm/sketch-module-web-view :)'
    )
  }
  webContents.isAudioMuted = function () {
    // TODO:??
    console.warn(
      'Not implemented yet, please open a PR on https://github.com/skpm/sketch-module-web-view :)'
    )
  }
  webContents.setZoomFactor = function (factor) {
    webview.setMagnification_centeredAtPoint(factor, CGPointMake(0, 0))
  }
  webContents.getZoomFactor = function (callback) {
    callback(Number(webview.magnification()))
  }
  webContents.setZoomLevel = function (level) {
    webContents.setZoomFactor(Math.pow(1.2, level))
  }
  webContents.getZoomLevel = function (callback) {
    callback(Math.log(Number(webview.magnification())) / Math.log(1.2))
  }
  webContents.setVisualZoomLevelLimits =
    function (/* minimumLevel, maximumLevel */) {
      // TODO:??
      console.warn(
        'Not implemented yet, please open a PR on https://github.com/skpm/sketch-module-web-view :)'
      )
    }
  webContents.setLayoutZoomLevelLimits =
    function (/* minimumLevel, maximumLevel */) {
      // TODO:??
      console.warn(
        'Not implemented yet, please open a PR on https://github.com/skpm/sketch-module-web-view :)'
      )
    }

  // TODO:
  // webContents.undo = function() {
  //   webview.undoManager().undo()
  // }
  // webContents.redo = function() {
  //   webview.undoManager().redo()
  // }
  // webContents.cut = webview.cut
  // webContents.copy = webview.copy
  // webContents.paste = webview.paste
  // webContents.pasteAndMatchStyle = webview.pasteAsRichText
  // webContents.delete = webview.delete
  // webContents.replace = webview.replaceSelectionWithText

  webContents.send = function () {
    const script =
      'window.postMessage({' +
      'isSketchMessage: true,' +
      "origin: '" +
      String(__command.identifier()) +
      "'," +
      'args: ' +
      JSON.stringify([].slice.call(arguments)) +
      '}, "*")'
    webview.evaluateJavaScript_completionHandler(script, null)
  }

  webContents.getNativeWebview = function () {
    return webview
  }

  browserWindow.webContents = webContents
}


/***/ },

/***/ "./node_modules/sketch-module-web-view/remote.js"
/*!*******************************************************!*\
  !*** ./node_modules/sketch-module-web-view/remote.js ***!
  \*******************************************************/
(module, __unused_webpack_exports, __webpack_require__) {

/* globals NSThread */
var threadDictionary = NSThread.mainThread().threadDictionary()

module.exports.getWebview = function (identifier) {
  return (__webpack_require__(/*! ./lib */ "./node_modules/sketch-module-web-view/lib/index.js").fromId)(identifier)
}

module.exports.isWebviewPresent = function isWebviewPresent(identifier) {
  return !!threadDictionary[identifier]
}

module.exports.sendToWebview = function sendToWebview(identifier, evalString) {
  if (!module.exports.isWebviewPresent(identifier)) {
    return
  }

  var panel = threadDictionary[identifier]
  var webview = null
  var subviews = panel.contentView().subviews()
  for (var i = 0; i < subviews.length; i += 1) {
    if (
      !webview &&
      !subviews[i].isKindOfClass(WKInspectorWKWebView) &&
      subviews[i].isKindOfClass(WKWebView)
    ) {
      webview = subviews[i]
    }
  }

  if (!webview || !webview.evaluateJavaScript_completionHandler) {
    throw new Error('Webview ' + identifier + ' not found')
  }

  webview.evaluateJavaScript_completionHandler(evalString, null)
}


/***/ },

/***/ "./node_modules/sketch-polyfill-fetch/lib/index.js"
/*!*********************************************************!*\
  !*** ./node_modules/sketch-polyfill-fetch/lib/index.js ***!
  \*********************************************************/
(module, __unused_webpack_exports, __webpack_require__) {

/* provided dependency */ var Promise = __webpack_require__(/*! ./node_modules/@skpm/promise/index.js */ "./node_modules/@skpm/promise/index.js");
/* globals NSJSONSerialization NSJSONWritingPrettyPrinted NSDictionary NSHTTPURLResponse NSString NSASCIIStringEncoding NSUTF8StringEncoding coscript NSURL NSMutableURLRequest NSMutableData NSURLConnection */
var Buffer;
try {
  Buffer = (__webpack_require__(/*! buffer */ "buffer").Buffer);
} catch (err) {}

function response(httpResponse, data) {
  var keys = [];
  var all = [];
  var headers = {};
  var header;

  for (var i = 0; i < httpResponse.allHeaderFields().allKeys().length; i++) {
    var key = httpResponse
      .allHeaderFields()
      .allKeys()
      [i].toLowerCase();
    var value = String(httpResponse.allHeaderFields()[key]);
    keys.push(key);
    all.push([key, value]);
    header = headers[key];
    headers[key] = header ? header + "," + value : value;
  }

  return {
    ok: ((httpResponse.statusCode() / 200) | 0) == 1, // 200-399
    status: Number(httpResponse.statusCode()),
    statusText: String(
      NSHTTPURLResponse.localizedStringForStatusCode(httpResponse.statusCode())
    ),
    useFinalURL: true,
    url: String(httpResponse.URL().absoluteString()),
    clone: response.bind(this, httpResponse, data),
    text: function() {
      return new Promise(function(resolve, reject) {
        const str = String(
          NSString.alloc().initWithData_encoding(data, NSASCIIStringEncoding)
        );
        if (str) {
          resolve(str);
        } else {
          reject(new Error("Couldn't parse body"));
        }
      });
    },
    json: function() {
      return new Promise(function(resolve, reject) {
        var str = String(
          NSString.alloc().initWithData_encoding(data, NSUTF8StringEncoding)
        );
        if (str) {
          // parse errors are turned into exceptions, which cause promise to be rejected
          var obj = JSON.parse(str);
          resolve(obj);
        } else {
          reject(
            new Error(
              "Could not parse JSON because it is not valid UTF-8 data."
            )
          );
        }
      });
    },
    blob: function() {
      return Promise.resolve(data);
    },
    arrayBuffer: function() {
      return Promise.resolve(Buffer.from(data));
    },
    headers: {
      keys: function() {
        return keys;
      },
      entries: function() {
        return all;
      },
      get: function(n) {
        return headers[n.toLowerCase()];
      },
      has: function(n) {
        return n.toLowerCase() in headers;
      }
    }
  };
}

// We create one ObjC class for ourselves here
var DelegateClass;

function fetch(urlString, options) {
  if (
    typeof urlString === "object" &&
    (!urlString.isKindOfClass || !urlString.isKindOfClass(NSString))
  ) {
    options = urlString;
    urlString = options.url;
  }
  options = options || {};
  if (!urlString) {
    return Promise.reject("Missing URL");
  }
  var fiber;
  try {
    fiber = coscript.createFiber();
  } catch (err) {
    coscript.shouldKeepAround = true;
  }
  return new Promise(function(resolve, reject) {
    var url = NSURL.alloc().initWithString(urlString);
    var request = NSMutableURLRequest.requestWithURL(url);
    request.setHTTPMethod(options.method || "GET");

    Object.keys(options.headers || {}).forEach(function(i) {
      request.setValue_forHTTPHeaderField(options.headers[i], i);
    });

    if (options.body) {
      var data;
      if (typeof options.body === "string") {
        var str = NSString.alloc().initWithString(options.body);
        data = str.dataUsingEncoding(NSUTF8StringEncoding);
      } else if (Buffer && Buffer.isBuffer(options.body)) {
        data = options.body.toNSData();
      } else if (
        options.body.isKindOfClass &&
        options.body.isKindOfClass(NSData) == 1
      ) {
        data = options.body;
      } else if (options.body._isFormData) {
        var boundary = options.body._boundary;
        data = options.body._data;
        data.appendData(
          NSString.alloc()
            .initWithString("--" + boundary + "--\r\n")
            .dataUsingEncoding(NSUTF8StringEncoding)
        );
        request.setValue_forHTTPHeaderField(
          "multipart/form-data; boundary=" + boundary,
          "Content-Type"
        );
      } else {
        var exception;
        data = NSJSONSerialization.dataWithJSONObject_options_error(
          options.body,
          NSJSONWritingPrettyPrinted,
          exception
        );
        if (exception != null) {
          var error = new TypeError(
            String(
              typeof exception.localizedDescription === "function"
                ? exception.localizedDescription()
                : exception
            )
          );
          reject(error);
          return;
        }
        request.setValue_forHTTPHeaderField(
          "" + data.length(),
          "Content-Length"
        );
      }
      request.setHTTPBody(data);
    }

    if (options.cache) {
      switch (options.cache) {
        case "reload":
        case "no-cache":
        case "no-store": {
          request.setCachePolicy(1); // NSURLRequestReloadIgnoringLocalCacheData
          break;
        }
        case "force-cache": {
          request.setCachePolicy(2); // NSURLRequestReturnCacheDataElseLoad
          break;
        }
        case "only-if-cached": {
          request.setCachePolicy(3); // NSURLRequestReturnCacheDataElseLoad
          break;
        }
      }
    }

    if (!options.credentials) {
      request.setHTTPShouldHandleCookies(false);
    }

    var finished = false;

    var connection = NSURLSession.sharedSession().dataTaskWithRequest_completionHandler(
      request,
      __mocha__.createBlock_function(
        'v32@?0@"NSData"8@"NSURLResponse"16@"NSError"24',
        function(data, res, exception) {
          if (fiber) {
            fiber.cleanup();
          } else {
            coscript.shouldKeepAround = false;
          }
          finished = true;
          try {
            if (exception) {
              var error = new TypeError(
                String(
                  typeof exception.localizedDescription === "function"
                    ? exception.localizedDescription()
                    : exception
                )
              );
              reject(error);
              return;
            }
            resolve(response(res, data));
          } catch (err) {
            reject(err);
          }
        }
      )
    );

    connection.resume();

    if (fiber) {
      fiber.onCleanup(function() {
        if (!finished) {
          connection.cancel();
        }
      });
    }
  });
}

module.exports = fetch;


/***/ },

/***/ "buffer"
/*!*************************!*\
  !*** external "buffer" ***!
  \*************************/
(module) {

"use strict";
module.exports = require("buffer");

/***/ },

/***/ "events"
/*!*************************!*\
  !*** external "events" ***!
  \*************************/
(module) {

"use strict";
module.exports = require("events");

/***/ },

/***/ "sketch"
/*!*************************!*\
  !*** external "sketch" ***!
  \*************************/
(module) {

"use strict";
module.exports = require("sketch");

/***/ },

/***/ "sketch/dom"
/*!*****************************!*\
  !*** external "sketch/dom" ***!
  \*****************************/
(module) {

"use strict";
module.exports = require("sketch/dom");

/***/ },

/***/ "sketch/settings"
/*!**********************************!*\
  !*** external "sketch/settings" ***!
  \**********************************/
(module) {

"use strict";
module.exports = require("sketch/settings");

/***/ },

/***/ "sketch/ui"
/*!****************************!*\
  !*** external "sketch/ui" ***!
  \****************************/
(module) {

"use strict";
module.exports = require("sketch/ui");

/***/ },

/***/ "./node_modules/@babel/runtime/helpers/esm/arrayLikeToArray.js"
/*!*********************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/esm/arrayLikeToArray.js ***!
  \*********************************************************************/
(__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ _arrayLikeToArray)
/* harmony export */ });
function _arrayLikeToArray(r, a) {
  (null == a || a > r.length) && (a = r.length);
  for (var e = 0, n = Array(a); e < a; e++) n[e] = r[e];
  return n;
}


/***/ },

/***/ "./node_modules/@babel/runtime/helpers/esm/arrayWithoutHoles.js"
/*!**********************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/esm/arrayWithoutHoles.js ***!
  \**********************************************************************/
(__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ _arrayWithoutHoles)
/* harmony export */ });
/* harmony import */ var _arrayLikeToArray_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./arrayLikeToArray.js */ "./node_modules/@babel/runtime/helpers/esm/arrayLikeToArray.js");

function _arrayWithoutHoles(r) {
  if (Array.isArray(r)) return (0,_arrayLikeToArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(r);
}


/***/ },

/***/ "./node_modules/@babel/runtime/helpers/esm/iterableToArray.js"
/*!********************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/esm/iterableToArray.js ***!
  \********************************************************************/
(__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ _iterableToArray)
/* harmony export */ });
function _iterableToArray(r) {
  if ("undefined" != typeof Symbol && null != r[Symbol.iterator] || null != r["@@iterator"]) return Array.from(r);
}


/***/ },

/***/ "./node_modules/@babel/runtime/helpers/esm/nonIterableSpread.js"
/*!**********************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/esm/nonIterableSpread.js ***!
  \**********************************************************************/
(__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ _nonIterableSpread)
/* harmony export */ });
function _nonIterableSpread() {
  throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}


/***/ },

/***/ "./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js"
/*!**********************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js ***!
  \**********************************************************************/
(__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ _toConsumableArray)
/* harmony export */ });
/* harmony import */ var _arrayWithoutHoles_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./arrayWithoutHoles.js */ "./node_modules/@babel/runtime/helpers/esm/arrayWithoutHoles.js");
/* harmony import */ var _iterableToArray_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./iterableToArray.js */ "./node_modules/@babel/runtime/helpers/esm/iterableToArray.js");
/* harmony import */ var _unsupportedIterableToArray_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./unsupportedIterableToArray.js */ "./node_modules/@babel/runtime/helpers/esm/unsupportedIterableToArray.js");
/* harmony import */ var _nonIterableSpread_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./nonIterableSpread.js */ "./node_modules/@babel/runtime/helpers/esm/nonIterableSpread.js");




function _toConsumableArray(r) {
  return (0,_arrayWithoutHoles_js__WEBPACK_IMPORTED_MODULE_0__["default"])(r) || (0,_iterableToArray_js__WEBPACK_IMPORTED_MODULE_1__["default"])(r) || (0,_unsupportedIterableToArray_js__WEBPACK_IMPORTED_MODULE_2__["default"])(r) || (0,_nonIterableSpread_js__WEBPACK_IMPORTED_MODULE_3__["default"])();
}


/***/ },

/***/ "./node_modules/@babel/runtime/helpers/esm/typeof.js"
/*!***********************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/esm/typeof.js ***!
  \***********************************************************/
(__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ _typeof)
/* harmony export */ });
function _typeof(o) {
  "@babel/helpers - typeof";

  return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) {
    return typeof o;
  } : function (o) {
    return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
  }, _typeof(o);
}


/***/ },

/***/ "./node_modules/@babel/runtime/helpers/esm/unsupportedIterableToArray.js"
/*!*******************************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/esm/unsupportedIterableToArray.js ***!
  \*******************************************************************************/
(__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ _unsupportedIterableToArray)
/* harmony export */ });
/* harmony import */ var _arrayLikeToArray_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./arrayLikeToArray.js */ "./node_modules/@babel/runtime/helpers/esm/arrayLikeToArray.js");

function _unsupportedIterableToArray(r, a) {
  if (r) {
    if ("string" == typeof r) return (0,_arrayLikeToArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(r, a);
    var t = {}.toString.call(r).slice(8, -1);
    return "Object" === t && r.constructor && (t = r.constructor.name), "Map" === t || "Set" === t ? Array.from(r) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? (0,_arrayLikeToArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(r, a) : void 0;
  }
}


/***/ }

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	const __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		const cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		const module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		if (!(moduleId in __webpack_modules__)) {
/******/ 			delete __webpack_module_cache__[moduleId];
/******/ 			const e = new Error("Cannot find module '" + moduleId + "'");
/******/ 			e.code = 'MODULE_NOT_FOUND';
/******/ 			throw e;
/******/ 		}
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = (module) => {
/******/ 		const getter = module && module.__esModule ?
/******/ 			() => (module['default']) :
/******/ 			() => (module);
/******/ 		__webpack_require__.d(getter, { a: getter });
/******/ 		return getter;
/******/ 	};
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	// define getter/value functions for harmony exports
/******/ 	__webpack_require__.d = (exports, definition) => {
/******/ 		for(var key in definition) {
/******/ 			if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 				Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 			}
/******/ 		}
/******/ 	};
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop));
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = (exports) => {
/******/ 		Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/ 	
/************************************************************************/
let __webpack_exports__ = {};
// This entry needs to be wrapped in an IIFE because it needs to be in strict mode.
(() => {
"use strict";
/*!***********************!*\
  !*** ./src/create.js ***!
  \***********************/
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* export default binding */ __WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _common__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./common */ "./src/common.js");
/* harmony import */ var sketch_module_web_view__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! sketch-module-web-view */ "./node_modules/sketch-module-web-view/lib/index.js");
/* harmony import */ var sketch_module_web_view__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(sketch_module_web_view__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _skpm_dialog__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @skpm/dialog */ "./node_modules/@skpm/dialog/lib/index.js");
/* harmony import */ var sketch_module_web_view_remote__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! sketch-module-web-view/remote */ "./node_modules/sketch-module-web-view/remote.js");




/* harmony default export */ function __WEBPACK_DEFAULT_EXPORT__(context) {
  var UI = __webpack_require__(/*! sketch/ui */ "sketch/ui"),
    Settings = __webpack_require__(/*! sketch/settings */ "sketch/settings"),
    Group = (__webpack_require__(/*! sketch/dom */ "sketch/dom").Group),
    Shape = (__webpack_require__(/*! sketch/dom */ "sketch/dom").Shape),
    fetch = __webpack_require__(/*! sketch-polyfill-fetch */ "./node_modules/sketch-polyfill-fetch/lib/index.js"),
    sketch = __webpack_require__(/*! sketch */ "sketch");
  var trueVersion = true;
  var version = parseInt(sketch.version.sketch.toString().match(/\d+/)[0], 10);
  if (version < 53) {
    trueVersion = false;
  }
  var doc = (__webpack_require__(/*! sketch/dom */ "sketch/dom").getSelectedDocument)();

  // Global settings
  var status = Settings.globalSettingForKey('user_status'),
    email = Settings.globalSettingForKey('user_email'),
    lastCheck = Settings.globalSettingForKey('last_check'),
    userId = Settings.globalSettingForKey('userId'),
    chartType = context.command.identifier();
  if (lastCheck === undefined) {
    var _today = Date.now();
    Settings.setGlobalSettingForKey('last_check', _today);
    lastCheck = Settings.globalSettingForKey('last_check');
  }
  var today = Date.now(),
    delta = today - lastCheck;
  if (Settings.globalSettingForKey('xchart.templates') == undefined && Settings.globalSettingForKey('conf') == undefined) {
    (0,_common__WEBPACK_IMPORTED_MODULE_0__.defaultConf)();
  } else if (Settings.globalSettingForKey('xchart.templates') == undefined && Settings.globalSettingForKey('conf') != undefined) {
    (0,_common__WEBPACK_IMPORTED_MODULE_0__.convertToTemplate)();
  }
  ;(0,_common__WEBPACK_IMPORTED_MODULE_0__.migrateCandleColors)();
  if (userId == undefined) {
    Settings.setGlobalSettingForKey('userId', NSUUID.UUID().UUIDString());
  }

  // Get Global Conf
  var templates = JSON.parse(Settings.globalSettingForKey('xchart.templates'));

  // Checking subscription asinc
  (0,_common__WEBPACK_IMPORTED_MODULE_0__.checkSubscribtion)(email);

  // Get Canvas
  var canvasObj = (0,_common__WEBPACK_IMPORTED_MODULE_0__.getCanvas)(context),
    canvas = canvasObj[0];

  if (canvas.length === 0) {
    // Studio provides a predictable starter frame when the canvas is empty.
    var starter = new Shape({ parent: doc.selectedPage, name: 'Chart Area', frame: { x: 0, y: 0, width: 320, height: 200 } });
    starter.style.fills = [];
    starter.style.borders = [];
    starter.selected = true;
    canvas = [{ layer: starter.id, height: 200, width: 320, x: starter.frame.x, y: starter.frame.y, layerType: starter.shapeType, startNum: 'false', parent: starter.parent.id, conf: undefined }];
  }

  // Pass request to webView
  if (canvas.length > 0 && trueVersion === true) {
    if (true) {
      // 已移除试用窗口限制
      var options = {
          identifier: 'chart-area-lab',
          width: 1200,
          height: 720,
          minWidth: 1080,
          minHeight: 640,
          show: false,
          minimizable: true,
          maximizable: true,
          resizable: true,
          alwaysOnTop: true,
          hidesOnDeactivate: false
        },
        browserWindow = new (sketch_module_web_view__WEBPACK_IMPORTED_MODULE_1___default())(options),
        webContents = browserWindow.webContents;
      browserWindow.setAlwaysOnTop(true);
      browserWindow._panel.setHidesOnDeactivate(false);
      browserWindow.show();
      var canvasData = {
        canvas: canvas,
        conf: templates
      };
      var dataStr = JSON.stringify(canvasData);
      webContents.on('did-finish-load', function () {
        webContents.executeJavaScript('dataMsg(' + dataStr + ')');
        browserWindow.show();
      });
      webContents.on('externalLinkClicked', function (url) {
        NSWorkspace.sharedWorkspace().openURL(NSURL.URLWithString(url));
      });
      webContents.on('nativeLog', function (type, meta) {
        if (type == 'csv') {
          var getFile = function getFile() {
            return _skpm_dialog__WEBPACK_IMPORTED_MODULE_2__.showOpenDialogSync({
              title: "选择 CSV 文件",
              filters: [{
                name: 'CSV',
                extensions: ['csv']
              }],
              properties: ['openFile']
            });
          };
          var selectedFiles = getFile();
          if (!selectedFiles || selectedFiles.length === 0) return;
          var url = selectedFiles[0];
          var result = String(NSString.stringWithContentsOfFile_encoding_error(url, NSUTF8StringEncoding, null));
          var shortName = url.split("/");
          var input = result.replace(/^\uFEFF/, '');
          var dataTable = [], row = [], field = '', quoted = false;
          for (var i = 0; i < input.length; i++) {
            var character = input[i];
            if (quoted) {
              if (character === '"' && input[i + 1] === '"') {
                field += '"';
                i += 1;
              } else if (character === '"') {
                quoted = false;
              } else {
                field += character;
              }
            } else if (character === '"' && field === '') {
              quoted = true;
            } else if (character === ',') {
              row.push(field);
              field = '';
            } else if (character === '\n' || character === '\r') {
              if (character === '\r' && input[i + 1] === '\n') i += 1;
              row.push(field);
              dataTable.push(row);
              row = [];
              field = '';
            } else {
              field += character;
            }
          }
          if (quoted) {
            (0,sketch_module_web_view_remote__WEBPACK_IMPORTED_MODULE_3__.sendToWebview)('chart', 'importFailed(' + JSON.stringify('CSV 中存在未闭合的引号') + ')');
            return;
          }
          if (field !== '' || row.length) {
            row.push(field);
            dataTable.push(row);
          }
          while (dataTable.length && dataTable[dataTable.length - 1].every(function (cell) {
            return cell === '';
          })) dataTable.pop();
          var tableObject = {
            name: shortName[shortName.length - 1],
            type: "csv",
            table: dataTable
          };
          var dataTableString = JSON.stringify(tableObject);
          var tableRequest = 'loadTableFile(' + dataTableString + ')';
          (0,sketch_module_web_view_remote__WEBPACK_IMPORTED_MODULE_3__.sendToWebview)('chart', tableRequest);
        } else if (type == 'http') {
          fetch(meta).then(function (res) {
            if (res.status && (res.status < 200 || res.status >= 300)) throw new Error('HTTP ' + res.status);
            return res.json();
          }).then(function (jsonData) {
            var shortName = meta.split("/");
            var jObject = {
              name: shortName[shortName.length - 1],
              json: jsonData
            };
            var jsonString = JSON.stringify(jObject);
            var jObjectRequest = 'loadJSON(' + jsonString + ')';
            (0,sketch_module_web_view_remote__WEBPACK_IMPORTED_MODULE_3__.sendToWebview)('chart', jObjectRequest);
          }).catch(function (error) {
            (0,sketch_module_web_view_remote__WEBPACK_IMPORTED_MODULE_3__.sendToWebview)('chart', 'importFailed(' + JSON.stringify('无法加载 JSON：' + error.message) + ')');
          });
        } else if (type == 'json') {
          var _getFile = function _getFile() {
            return _skpm_dialog__WEBPACK_IMPORTED_MODULE_2__.showOpenDialogSync({
              title: "选择 JSON 文件",
              filters: [{
                name: 'JSON',
                extensions: ['json']
              }],
              properties: ['openFile']
            });
          };
          var _selectedFiles = _getFile();
          if (!_selectedFiles || _selectedFiles.length === 0) {
            (0,sketch_module_web_view_remote__WEBPACK_IMPORTED_MODULE_3__.sendToWebview)('chart', 'importCancelled()');
            return;
          }
          try {
            var _url = _selectedFiles[0];
            var _result = NSString.stringWithContentsOfFile_encoding_error(_url, NSUTF8StringEncoding, null),
              JSONresult = JSON.parse(String(_result)),
              _shortName = _url.split("/");
            var jObject = {
              name: _shortName[_shortName.length - 1],
              json: JSONresult
            };
            var jsonString = JSON.stringify(jObject);
            var jObjectRequest = 'loadJSON(' + jsonString + ')';
            (0,sketch_module_web_view_remote__WEBPACK_IMPORTED_MODULE_3__.sendToWebview)('chart', jObjectRequest);
          } catch (error) {
            (0,sketch_module_web_view_remote__WEBPACK_IMPORTED_MODULE_3__.sendToWebview)('chart', 'importFailed(' + JSON.stringify('JSON 文件无效：' + error.message) + ')');
          }
        } else if (type == 'create') {
          try {
          var data = JSON.parse(meta);
	          if (data.studioSize && data.studioSize.width >= 40 && data.studioSize.height >= 40) {
	            // Studio 尺寸预设：创建前将 Chart Area 图层调整到预设尺寸（x/y 保持不变），
	            // 适配层 resourceCanvas 会读取真实 frame，因此此处改 frame 即生效
	            data.canvas.forEach(function (item) {
	              var targetLayer = doc.getLayerWithID(item.layer);
	              if (targetLayer) {
	                targetLayer.frame.width = data.studioSize.width;
	                targetLayer.frame.height = data.studioSize.height;
	              }
	            });
	          }
	          if (data.updateTemplate) {
	            data.conf.settings.updatable = data.conf.templateRef && data.conf.templateRef.mode === 'linked';
	            var newSettings = new Array();
            templates.forEach(function (template) {
				  if (String(template.id) === String(data.conf.settings.id)) {
	                var updatedTemplate = JSON.parse(JSON.stringify(data.conf.settings));
	                delete updatedTemplate.updatable;
	                newSettings.push(updatedTemplate);
              } else {
                newSettings.push(template);
              }
	            });
	            Settings.setGlobalSettingForKey('xchart.templates', JSON.stringify(newSettings));
	            if (data.conf.templateRef && data.conf.templateRef.mode === 'linked') data.conf.overrides = {};
	          } else {
	            data.conf.settings.updatable = data.conf.templateRef ? data.conf.templateRef.mode === 'linked' : false;
	          }
          ;(0,_common__WEBPACK_IMPORTED_MODULE_0__.createChart)(data.canvas, data.conf);
          UI.message(data.conf.data.fullChartName + '已创建，可在图层列表中继续编辑');
          browserWindow.destroy();
          } catch (error) {
            UI.message('创建图表失败：' + error.message);
            (0,sketch_module_web_view_remote__WEBPACK_IMPORTED_MODULE_3__.sendToWebview)('chart', 'creationFailed(' + JSON.stringify(error.message || '创建图表失败') + ')');
          }
        }
      });

      // 修复：覆盖原生红点关闭按钮（CocoaScript 无法桥接 windowShouldClose 的 BOOL 返回值，导致红点关不了）
      var closeButton = browserWindow._panel.standardWindowButton(NSWindowCloseButton);
      if (closeButton) {
        closeButton.setCOSJSTargetFunction(function () {
          browserWindow.destroy();
        });
      }
      browserWindow.loadURL(__webpack_require__(/*! ../assets/createChart.html */ "./assets/createChart.html"));
    }
  } else {
    UI.message('请升级 Sketch 到 v53 以上版本以使用 X-Chart');
  }
}
})();

exports = __webpack_exports__;
/******/ })()
;
    if (key === 'default' && typeof exports === 'function') {
      exports(context);
    } else if (typeof exports[key] !== 'function') {
      throw new Error('Missing export named "' + key + '". Your command should contain something like `export function " + key +"() {}`.');
    } else {
      exports[key](context);
    }
  } catch (err) {
    if (typeof process !== 'undefined' && process.listenerCount && process.listenerCount('uncaughtException')) {
      process.emit("uncaughtException", err, "uncaughtException");
    } else {
      throw err
    }
  }
}
globalThis['onRun'] = __skpm_run.bind(this, 'default')
